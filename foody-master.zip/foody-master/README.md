# foody

1. Install node_modules
  npm install
  
2. Run Project

  Run project on android
  'react-native run-android'
  
OR

  Run project on ios
  'react-native run-ios'
