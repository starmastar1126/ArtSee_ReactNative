// WARNING static svgs doesn't work for release build on Android using react-native-svg-uri
const images = {
  //defaultAvatar1: require('../static/default_avatar1.png'),
}

export default images
