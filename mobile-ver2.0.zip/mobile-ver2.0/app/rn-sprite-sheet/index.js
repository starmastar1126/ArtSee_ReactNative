import SpriteSheet from './src/SpriteSheet.js';
export default SpriteSheet;
