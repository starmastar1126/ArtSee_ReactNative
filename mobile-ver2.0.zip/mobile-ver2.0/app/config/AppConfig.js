// Simple React Native specific changes

export default {
  // font scaling override - RN default is on
  apiUrl: 'https://artseeapp.com/api',
  siteUrl: 'https://artseeapp.com',
  APP_TITLE: 'ARTSEE',
  DEFAULT_PASSWORD: '123'
}
