export default function createHelpers({fetch}) {
  return {
    fetch
  }
}
