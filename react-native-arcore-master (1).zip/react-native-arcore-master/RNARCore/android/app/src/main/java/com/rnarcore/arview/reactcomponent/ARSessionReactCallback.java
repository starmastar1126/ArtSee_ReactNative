package com.rnarcore.arview.reactcomponent;

/**
 * Created by vbaicu on 2/19/18.
 */

public interface ARSessionReactCallback {
    void invoke(String data);
}
