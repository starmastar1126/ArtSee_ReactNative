export const APP_TITLE = 'ARTSEE'
export const SITE_URL = 'https://artseeapp.com'
export const API_URL = 'https://artseeapp.com/api'
export const DEFAULT_PASSWORD = '123'

export const THEME = {
  primaryColor: '#000', // '#d81983',
  primaryLightColor: '#67daff',
  primaryDarkColor: '#007ac1',
  secondaryColor: '#0d47a1',
  secondaryLightColor: '#5472d3',
  secondaryDarkColor: '#002171',
  disabledColor: '#E0E0E0',
  headerBackground: '#ffffff',
  headerColor: '#000',
}
