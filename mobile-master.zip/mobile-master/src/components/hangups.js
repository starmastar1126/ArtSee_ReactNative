import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach, map } from 'lodash'
import realm from '@store/realm';
import HangupItem from "./hangupItem";
import {SwipeListView} from "react-native-swipe-list-view";
// import Swiper from 'react-native-swiper';

@inject('stateStore', 'hangupStore')
@observer
class HangupsScreen extends Component {
  constructor(props) {
    super(props)
    this.data_source = realm.objects('hangups').sorted('isFavorite', true);
    this.data_source.addListener(this.onChange);
  }

  closeRow(rowMap, rowKey) {
    if (rowMap[rowKey]) {
      rowMap[rowKey].closeRow();
    }
  }

  deleteRow(rowMap, rowKey) {
    this.closeRow(rowMap, rowKey);
    this.props.hangupStore.delete(rowKey)
  }

  onRowDidOpen = (rowKey, rowMap) => {
    setTimeout(() => {
      this.closeRow(rowMap, rowKey);
    }, 3000);
  }

  onFocus = () => {
    console.log('HangupsScreen focus');
    this.forceUpdate();
  }

  handleFave = (id) => {
    this.props.hangupStore.toggleFavorit(id)
  }

  onPressItem = (item) => {
    this.props.navigation.navigate('HangupEdit', {item: item})
  }

  onChange = (name, changes) => {
    console.log('onChange', this.data_source, this.data_source && this.data_source.length, this.data_source && this.data_source.slice())

    this.forceUpdate();
  }

  renderItem = ({item, index}) => {
    return (
      <HangupItem item={item} index={index} onPressItem={this.onPressItem} onFave={this.handleFave}/>
    )
  }

  componentWillMount() {
    this.willFocusSubscription = this.props.navigation.addListener('willFocus', this.onFocus)
  }

  componentDidMount() {
  }

  componentWillUnmount() {
    this.willFocusSubscription.remove()
  }

  render() {
    console.log('hangups', this.data_source.slice())
    const data = map(this.data_source.slice(), (i) => {return {...i, key: i.id}})

    return (
      <View style={styles.container}>
        {/*<FlatList*/}
          {/*keyExtractor={(item) => `${item.id}`}*/}
          {/*data={this.data_source.slice()}*/}
          {/*renderItem={this.renderItem}*/}
        {/*/>*/}
        <SwipeListView
          useFlatList={true}
          disableRightSwipe
          closeOnRowPress
          closeOnRowBeginSwipe={true}
          data={data}
          renderItem={this.renderItem}
          renderHiddenItem={ (rowData, rowMap) => (
            <View style={styles.rowBack}>
              <TouchableOpacity style={[styles.backRightBtn, styles.backRightBtnRight]} onPress={ _ => this.deleteRow(rowMap, rowData.item.id) }>
                <Text style={styles.backTextWhite}>Delete</Text>
              </TouchableOpacity>
            </View>
          )}
          rightOpenValue={-100}
          // onRowDidOpen={this.onRowDidOpen}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  backTextWhite: {
    fontSize: 18,
    color: '#FFF'
  },
  rowFront: {
    alignItems: 'center',
    backgroundColor: '#CCC',
    borderBottomColor: 'black',
    borderBottomWidth: 1,
    justifyContent: 'center',
    height: 50,
  },
  rowBack: {
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 15,
  },
  backRightBtn: {
    alignItems: 'center',
    bottom: 0,
    justifyContent: 'center',
    position: 'absolute',
    top: 0,
    width: 100
  },
  backRightBtnRight: {
    backgroundColor: 'red',
    right: 0
  },
});

export default HangupsScreen;
