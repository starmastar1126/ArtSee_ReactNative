import React, { Component } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView, Button, Alert,
  TouchableWithoutFeedback, Dimensions
} from 'react-native';
import Share from 'react-native-share';
import {observer, inject} from "mobx-react/native"
import RNFetchBlob from 'react-native-fetch-blob'
import {Icon} from "react-native-elements";
import { map, size } from 'lodash'
import realm from '@store/realm';

import {THEME} from "../settings";
import StandaloneInfo from "../images/StandaloneInfo.png"
import StandaloneAdd from "../images/StandaloneAdd.png"
import FullWidthImage from "../common/FullWidthImage";
import {backButton} from "./ui";
import DragArtItem from "./dragArtItem";
import {captureScreen} from "react-native-view-shot";

let Window = Dimensions.get('window');
const artPadding = 21

@inject('stateStore', 'hangupStore')
@observer
class HangupEditScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state
    return {
      title: 'Edit Hangup',
      headerLeft: backButton(navigation),
      headerRight: (<Icon
        name={'share-alternative'}
        type='entypo'
        color={THEME.headerColor}
        iconStyle={{marginRight: 16}}
        onPress={params && params.handleShare}
      />)
    }
  }

  constructor(props) {
    super(props)
  }

  state = {
    show: true,
    activeArtId: null,
  }

  onChange = (name, changes) => {
    console.log('onChange', this.data_source, this.data_source && this.data_source.length, this.data_source && this.data_source.slice())

    this.forceUpdate();
  }

  // onFocus = () => {
  //   console.log('Hangup Edit focus');
  //   this.refreshData()
  //   this.forceUpdate();
  // }

  handleInfo = (item) => {
    this.handleBlur()
    this.props.navigation.navigate('HangupArtList', {item: item})
  }

  handleAddArt = (item) => {
    this.handleBlur()
    this.props.navigation.navigate('SelectArt', {wall: item.wall, updateId: item.id})
  }

  handleShare = () => {
    this.handleBlur()
    const item = this.data_source && this.data_source[0]
    console.log('handleShare', item)
    const imageSource = item && item.wall && parseInt(item.wall.imagePath)
    let name = ''
    let author = ''

    if (size(item.arts.slice()) === 1) {
      name = `${item.arts[0].imageName}`
    } else {
      name = size(item.arts.slice()) === 0 ? item.wall && item.wall.wallName && item.wall.wallName.toUpperCase() : 'MULTIPLE PIECES'
    }

    if (size(item.arts.slice()) > 0) {
      if (size(item.arts.slice()) === 1) {
        author = `by ${item.arts[0].artistName}`
      } else {
        author = `in ${item.wall && item.wall.wallName && item.wall.wallName.toUpperCase()}`
      }
    }
    if(item.imagePath)
    {
      RNFetchBlob.fs.readFile(item.imagePath, 'base64').then((image) => {
        Share.open(
          {
            title: '',
            message: `Check out ${name} ${author}!\nBrought to you by ArtSee (https://artseeapp.com)\nDownload the app now at http://appstore.com/arthangup`,
            // url: item.imagePath,  // TODO add image
            url: 'data:image/jpeg;base64,' + image,
            type: 'image/jpeg',
          }).then(result => console.log(result)).catch(errorMsg => console.log(errorMsg))
          .catch((err) => {
            console.log('error')
          });
      }).catch(err =>{
        console.log(err);
        Share.open(
          {
            title: '',
            message: `Check out ${name} ${author}!\nBrought to you by ArtSee (https://artseeapp.com)\nDownload the app now at http://appstore.com/arthangup`,
            // url: item.imagePath,  // TODO add image
            url: 'data:image/jpeg;base64,',
            type: 'image/jpeg',
          }).then(result => console.log(result)).catch(errorMsg => console.log(errorMsg))
          .catch((err) => {
            Share.open(
              {
                title: '',
                message: `Check out ${name} ${author}!\nBrought to you by ArtSee (https://artseeapp.com)\nDownload the app now at http://appstore.com/arthangup`,
                // url: item.imagePath,  // TODO add image
                url: 'data:image/jpeg;base64,',
                type: 'image/jpeg',
              }).then(result => console.log(result)).catch(errorMsg => console.log(errorMsg))
              .catch((err) => {
                console.log('error')
              });
            console.log('error')
          });
      });
    }
    else {
      Share.open(
        {
          title: '',
          message: `Check out ${name} ${author}!\nBrought to you by ArtSee (https://artseeapp.com)\nDownload the app now at http://appstore.com/arthangup`,
          // url: item.imagePath,  // TODO add image
          url: 'data:image/jpeg;base64,',
          type: 'image/jpeg',
        }).then(result => console.log(result)).catch(errorMsg => console.log(errorMsg))
        .catch((err) => {
          console.log('error')
        });
    }
  }

  handleDelete = (id, artId) => {
    Alert.alert(
      'Delete Art',
      '',
      [
        {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        {text: 'OK', onPress: () => this.props.hangupStore.deleteArt(id, artId, () => {
          this.handleSaveImage(id, artId)
        })},
      ],
      { cancelable: true }
    )

  }

  handleRotateForward = (id, artId) => {
    this.props.hangupStore.rotate(id, artId, 90, () => {
        this.handleSaveImage(id, artId)
    })
  }

  handleRotateBack = (id, artId) => {
    this.props.hangupStore.rotate(id, artId, -90, () => {
        this.handleSaveImage(id, artId)
    })
  }

  handleSaveImage = (id, artId, x = null, y = null) => {
      const imageContainer = {x: this.state.x, y: this.state.y, width: this.state.width, height: this.state.height}

      console.log('handleSaveImage', imageContainer)
      this.setState({show: false}, () => {
          this.props.hangupStore.setXY(id, artId,
              x, y,
              imageContainer, this.refs['full'], (res) => {
                  console.log('res setXY', res)
                  this.setState({show: true})
              })
      })
  }
  handleDrag = (_value, id, art) => {
    console.log('_value', _value)
    console.log('window state', Window.width, Window.height, this.state.x, this.state.width, this.state.y, this.state.height)
    const imageContainer = {x: this.state.x, y: this.state.y, width: this.state.width, height: this.state.height}
    this.setState({show: false}, () => {
      this.props.hangupStore.setXY(id, art.id,
        _value.x + artPadding - (this.state.x + this.state.width / 2) , _value.y + artPadding - (this.state.y + this.state.height / 2),
        imageContainer, this.refs['full'], (res) => {
        console.log('res setXY', res)
        this.setState({show: true})
      })
    })
    // console.log('handleDrag', e, state, state.vx, state.vy, state.dx, state.dy)
  }
  
  handleFocus = (id) => {
    console.log('handleFocus', id)

    this.setState({activeArtId: id})
  }

  handleBlur = () => {
    console.log('handleBlur')
    this.setState({activeArtId: null})
  }

  refreshData = () => {
    const item = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.item || {};

    console.log('item', item)
    if (item) {
      this.data_source = realm.objects('hangups').filtered(`id = "${item.id}"`);
      this.data_source.addListener(this.onChange);
    }
  }

  componentWillMount() {
    this.props.navigation.setParams({ handleShare: this.handleShare });
    // this.willFocusSubscription = this.props.navigation.addListener('willFocus', this.onFocus)
    this.refreshData()
  }

  componentWillUnmount() {
    // this.willFocusSubscription.remove()
  }

  render() {
    const item = this.data_source && this.data_source[0]
    const imageSource = item && item.wall && parseInt(item.wall.imagePath)
    
    return (<View style={{flex: 1}}>
        <TouchableWithoutFeedback onPress={() => this.handleBlur()}>
          <View style={styles.container} ref="full">
            <View style={{margin: 16, marginTop: 24, height: 40}}></View>
            <View
              onLayout={(event) => {console.log('onLayout', event.nativeEvent.layout);return this.setState({
                x : event.nativeEvent.layout.x,
                y : event.nativeEvent.layout.y,
                width : event.nativeEvent.layout.width,
                height : event.nativeEvent.layout.height
              }, () => {
                console.log('onLayout imagePath', this.state, item.imagePath)
                // if (item && !item.imagePath && item.arts && item.arts[0]) {
                //     this.handleSaveImage(item.id, item.arts[0].id, 0, 148)
                // }
              })}}
            >
              {(item && item.wall && item.wall.imagePath) || imageSource
                ? <FullWidthImage isSource={imageSource > 0} source={imageSource > 0 ? imageSource : item && item.wall && `file://${item.wall.imagePath}`} />
                : null
              }
            </View>
            <View style={{margin: 16, marginBottom: 24, display: 'flex', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
              <View>
                <TouchableOpacity onPress={() => this.handleInfo(item)}>
                  <Image source={StandaloneInfo}/>
                </TouchableOpacity>
              </View>
              <View>
                <Text
                  style={[styles.textStyle, {fontSize: 16}]}
                >
                  {item && item.wall && item.wall.wallName && item.wall.wallName.toUpperCase()}
                </Text>
              </View>
              <View>
                <TouchableOpacity onPress={() => this.handleAddArt(item)}>
                  <Image source={StandaloneAdd}/>
                </TouchableOpacity>
              </View>
            </View>
            {this.state.width && this.state.height ?
              item && item.arts && map(item.arts.slice(), (art, index) => {
                const k = item.wall.width / art.width
                const k2 = Window.width / item.wall.pixelWidth
                const scaleWidth = k2 * item.wall.pixelWidth / k
                const scaleHeight = art.pixelHeight * scaleWidth / art.pixelWidth
                console.log('artXY', art.x, art.y, k, k2, scaleWidth, scaleHeight)
                return (
                  <DragArtItem
                    key={art.id}
                    active={this.state.activeArtId === art.id}
                    show={this.state.show}
                    imagePath={art.imagePath}
                    reverse={false}
                    // offsetX={Window.width / 2 + art.x - artPadding}
                      offsetX={this.state.x + this.state.width / 2 + art.x - artPadding}
                    // offsetY={Window.height / 2 + art.y - artPadding}
                    offsetY={this.state.y + this.state.height / 2 + art.y - artPadding}
                    rotate={art.rotation}
                    width={scaleWidth}
                    height={scaleHeight}
                    onDrag={(state2) => this.handleDrag(state2, item.id, art)}
                    onFocus={() => this.handleFocus(art.id)}
                    onDelete={() => this.handleDelete(item.id, art.id)}
                    onRotateForward={() => this.handleRotateForward(item.id, art.id)}
                    onRotateBack={() => this.handleRotateBack(item.id, art.id)}
                  />
                )
              })
              : null
            }
          </View>
        </TouchableWithoutFeedback>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  },
});

export default HangupEditScreen;
