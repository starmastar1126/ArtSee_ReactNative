import React, { Component } from 'react';
import {View, Text, StyleSheet, TouchableWithoutFeedback, TouchableOpacity, FlatList, Image, ScrollView, Button, Modal} from 'react-native';
import {observer, inject} from "mobx-react/native"
import { size, trim } from 'lodash'
import {backButton, cancelButton} from "./ui";
import {THEME} from "../settings";
import Gestures from "react-native-easy-gestures";

const letter = {width: 11, height: 8.5}

@inject('stateStore', 'wallStore')
@observer
class WallRetouch extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      title: 'Retouch Wall',
      headerLeft: cancelButton(navigation, true),
      // headerRight: (<View style={{flexDirection: 'row'}}>
      //   <TouchableOpacity
      //     onPress={navigation.state.params.handleSave}
      //     style={{marginRight: 16}}
      //   >
      //     <Text style={{color: '#000'}}>Save</Text>
      //   </TouchableOpacity>
      // </View>)
    }
  }

  state = {
    width: 0,
    height: 0,
    tab: 0,
    showInfo: false,
    scale: 1,
  }

  constructor(props) {
    super(props)
  }

  onNavPress = (newTab, force = true) => {
    const {tab} = this.state
    if (tab === newTab && !force) return

    this.setState({tab: newTab, prevTab: this.state.tab})
  }

  handleResize = (event, styles) => {

    const scale = styles && styles.transform && styles.transform[0] && styles.transform[0].scale || 1
    const width = 11 * this.state.width / 110 / scale
    console.log('handleResize', styles, scale, width);

    this.setState({scale})
  }

  handleInfo = () => {
    this.setState({showInfo: !this.state.showInfo})
  }

  submit = () => {
    const { scale } = this.state
    const photoSource = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.photoSource || null;
    const width = 11 * this.state.width / 110 / scale
    this.props.navigation.navigate('WallCreate', {photoSource, width});
  }

  componentWillMount() {
    const { params } = this.props.navigation && this.props.navigation.state

    this.props.navigation.setParams({ handleSave: this.submit});
  }

  render() {
    const { params } = this.props.navigation && this.props.navigation.state
    // const item = params && params.item

    const photoSource = params && params.photoSource || null;
    const imageSource = photoSource && parseInt(photoSource)

    console.log('photoSource', photoSource)
    console.log('item', this.state)
    return (
      <View style={styles.container}>
        <View style={{flex: 1 }}
          onLayout={(event) => {console.log('onLayout', event.nativeEvent.layout);return this.setState({
            width : event.nativeEvent.layout.width,
            height : event.nativeEvent.layout.height
           })}}
        >
          <Image source={imageSource > 0 ? imageSource : {uri: `file://${photoSource}`}} style={{position: 'absolute', width: this.state.width, height: this.state.height, resizeMode: 'contain'}} />
          {this.state.width
            ? (<Gestures
              styles={{zIndex: 999, left: this.state.width / 2 - 55, top: this.state.height / 2 - 42}}
              rotatable={false}
              scalable={true}
              onChange={(event, styles) => this.handleResize(event, styles)}
            >
              <View style={{width: 110, height: 85, backgroundColor: '#ddd', justifyContent: 'center', alignItems: 'center', opacity: 0.8, borderColor: '#000', borderWidth: 1}}>
              </View>
            </Gestures>)
            : null
          }
        </View>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

//make this component available to the app
export default WallRetouch;
