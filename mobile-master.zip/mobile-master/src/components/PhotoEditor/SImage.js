// @flow
import * as React from "react";
import {Surface} from "gl-react-native";

import GLImage from "./GLImage";

type FilterProps = {
    uri: string,
    onDraw?: () => mixed
};

export default class SImage extends React.PureComponent<FilterProps> {

    render(): React.Node {
        const {style, uri, onDraw} = this.props;
        const source = { uri };
        return (
            <Surface {...{style}}>
                <GLImage {...{source, onDraw}} />
            </Surface>
        );
    }
}
