import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView, Button } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { size, trim } from 'lodash'
import {backButton} from "./ui";
import {FormInput} from "react-native-elements";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";

@inject('stateStore', 'wallStore')
@observer
class WallCreateScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      title: params && params.update ? 'Edit Wall' : 'Add Wall',
      headerLeft: params && params.update ? (<TouchableOpacity onPress={() => navigation.goBack()} style={{marginHorizontal: 16}}>
        <Text>Cancel</Text>
      </TouchableOpacity>) : backButton(navigation),
      headerRight: (<TouchableOpacity
        onPress={navigation.state.params.handleSave}
        disabled={navigation.state.params.disabled}
        style={{marginRight: 16}}
      >
        <Text style={{color: navigation.state.params.disabled ? '#aaa' : '#000'}}>{params && params.update ? 'Save' : 'Add'}</Text>
      </TouchableOpacity>)
    }
  }

  state = {
    width: '',
    height: '',
    title: '',
    wallName: '',
    wallDescription: '',
  }

  constructor() {
    super()
  }

  validate = () => {
    const { params } = this.props.navigation && this.props.navigation.state
    const item = params && params.item
    const { width, height, wallName } = this.state
    let disabled = true

    if (parseFloat(width) > 0 && parseFloat(height) > 0  && size(wallName) > 0) {
      disabled = false
    }

    this.props.navigation.setParams({ handleSave: item ? this.update : this.submit, update: !!item, disabled: disabled });
  }

  submit = () => {
    const photoSource = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.photoSource || null;

    this.props.wallStore.create({...this.state}, photoSource)
    this.props.navigation.popToTop()
  }

  update = () => {
    this.props.wallStore.update({...this.state}, () => {
      this.props.navigation.popToTop()
    })
  }

  handleChangeText = (name) => (value) => {
    console.log('handleChangeText', name, value)
    const newState = {[name]: value}
    const { params } = this.props.navigation && this.props.navigation.state
    const item = params && params.item

    const photoSource = this.state.photoSource
    const k = item ? item.height / item.width : (photoSource ? photoSource.height / photoSource.width : (params && params.scale ? params.scale : 1))

    if (name === 'width') {
      newState['height'] = parseFloat(value) > 0 ? `${k * parseFloat(value)}` : ''
    }

    if (name === 'height') {
      newState['width'] = k > 0 && parseFloat(value) > 0 ? `${parseFloat(value) / k}` : ''
    }

    this.setState(newState, () => {
      this.validate()
    })
  }

  onPressItem = (item) => {
    this.props.navigation.navigate('ArtDetail', {item: item})
  }

  componentWillMount() {
    const { params } = this.props.navigation && this.props.navigation.state
    const item = params && params.item

    this.props.navigation.setParams({ handleSave: item ? this.update : this.submit, update: !!item, disabled: true });

    const width = params && params.width || {}
    const height = params && params.height || {}
    console.log('===========width',width);
    console.log('===========height',height);
    
    if (width) {
      this.handleChangeText('width')(width)
    }
    if(height) {
      this.handleChangeText('height')(height)
    }
    if (item) {
      this.setState({...item})
    }
  }

  render() {
    const { params } = this.props.navigation && this.props.navigation.state
    const item = params && params.item
    const imageSource = item && parseInt(item.imagePath)
    const photoSource = item
      ? (imageSource > 0 ? imageSource : {uri: `file://${item.imagePath}`})
      : params && params.photoSource || null;

    console.log('item', this.state)
    return (
      <View style={styles.container}>
        <KeyboardAwareScrollView scrollEnables={false} style={styles.container}>
          <View style={{height: 250, flex: 1, display: 'flex', flexDirection: 'row', justifyContent: 'center', marginTop: 16, marginBottom: 8}}>
            <Image source={photoSource} style={{width: 400, height: 250, resizeMode: 'contain'}} />
          </View>
          <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
            <FormInput
              underlineColorAndroid='transparent'
              containerStyle={styles.containerStyle}
              inputStyle={[styles.inputStyle, {textAlign: 'center', width: 60}]}
              keyboardType="numeric"
              placeholder="W"
              value={`${Math.round(this.state.width * 100) / 100}`}
              onChangeText={this.handleChangeText('width')}
            />
            <Text style={{lineHeight: 35}}> x </Text>
            <FormInput
              underlineColorAndroid='transparent'
              containerStyle={styles.containerStyle}
              inputStyle={[styles.inputStyle, {textAlign: 'center', width: 60}]}
              keyboardType="numeric"
              placeholder="H"
              value={`${Math.round(this.state.height * 100) / 100}`}
              onChangeText={this.handleChangeText('height')}
            />
          </View>

          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder="Name"
            value={this.state.wallName}
            onChangeText={this.handleChangeText('wallName')}
          />

          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={[styles.containerStyle, {height: 120}]}
            multiline
            numberOfLines={8}
            inputStyle={[styles.inputStyle]}
            value={this.state.wallDescription}
            onChangeText={this.handleChangeText('wallDescription')}
          />

        </KeyboardAwareScrollView>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  containerStyle: {
    borderColor: 'grey',
    borderWidth: 1,
    borderRadius: 5,
    margin: 0,
    marginTop: 8,
  },
  inputStyle: {
  },
  subTitle: {
    marginTop: 16,
    color: '#000',
    fontSize: 20,
    marginHorizontal: 16
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  },
  bottomTextStyle: {
    fontSize: 14,
    color: '#000'
  },
  contact: {
    color: '#e53935'
  }
});

//make this component available to the app
export default WallCreateScreen;
