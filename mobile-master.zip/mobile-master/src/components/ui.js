import React from 'react';
import {TouchableOpacity, Image, Text} from 'react-native';
import {Icon} from "react-native-elements";
import {THEME} from "../settings";
import closeBtn from "../images/Close.png"

export const drawerButton = (navigation) =>
  <Icon
    name='menu'
    type='entypo'
    color={THEME.headerColor}
    iconStyle={{paddingLeft: 16}}
    onPress={() => {
      // Coming soon: navigation.navigate('DrawerToggle')
      // https://github.com/react-community/react-navigation/pull/2492
      // if (navigation.state.index === 0) {
      navigation.navigate('DrawerOpen')
      // } else {
      //   navigation.navigate('DrawerClose')
      // }
    }}
  />

export const closeButton = (navigation, screen = null) =>
  <TouchableOpacity onPress={() => navigation.popToTop()}>
    <Image source={ closeBtn }/>
  </TouchableOpacity>

export const cancelButton = (navigation, back = null) =>
  <TouchableOpacity onPress={() => back ? navigation.goBack() : navigation.popToTop()} style={{marginHorizontal: 16}}>
    <Text>Cancel</Text>
  </TouchableOpacity>

export const backButton = (navigation) =>
  <Icon
    name={'chevron-left'}
    type='entypo'
    color={THEME.headerColor}
    iconStyle={{paddingLeft: 16}}
    onPress={() => {
      navigation.goBack()
    }}
  />

export const emptyButton = (navigation, icon = null, screen = null) =>
  <View
    name={icon || 'chevron-left'}
    type='entypo'
    color={THEME.headerColor}
    iconStyle={{paddingLeft: 16}}
    onPress={() => {
      navigation.goBack(screen)
    }}
  />