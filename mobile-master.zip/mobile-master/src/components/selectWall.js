import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import realm from '@store/realm';

import WallItem from "./wallItem";
import {backButton, cancelButton} from "./ui";

@inject('hangupStore')
@observer
class SelectWallScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      title: 'Select a Wall',
      headerLeft: <View style={{marginRight: 16}}>{params && params.back ? backButton(navigation) : cancelButton(navigation)}</View>,
    }
  }

  constructor(props) {
    super(props)
    this.data_source = realm.objects('walls')
    // this.data_source.addListener(this.onChange);
  }

  onPressItem = (item) => {
    const { params } = this.props.navigation && this.props.navigation.state
    const art = params && params.art

    if (art) {
      this.props.navigation.popToTop()
      this.props.hangupStore.create({wall:item, art: art}, (res) => {
        console.log('hangupStore.create res', res)
        if (res) {
          this.props.navigation.navigate('HangupEdit', {item: res})
        }
      })
    } else {
      this.props.navigation.navigate('SelectArt', {wall: item})
    }
  }

  onChange = (name, changes) => {
    // console.log('onChange', this.data_source, this.data_source && this.data_source.length, this.data_source && this.data_source.slice())

    // this.forceUpdate();
  }

  renderWall = ({item, index}) => {
    return (
      <WallItem item={item} index={index} onPressItem={this.onPressItem} selectMode />
    )
  }

  componentDidMount() {
    const { params } = this.props.navigation && this.props.navigation.state
    const art = params && params.art

    if (art) {
      this.props.navigation.setParams({back: true})
    }
  }

  render() {
    const list = (<View>
      <FlatList
        keyExtractor={(item) => `${item.id}`}
        data={this.data_source && this.data_source.length && this.data_source.sorted('isFavorite', true).slice() || []}
        renderItem={this.renderWall}
      />
    </View>)
    return (
      <View style={styles.container}>
        {list}
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  }
});

//make this component available to the app
export default SelectWallScreen;
