import React, { Component } from 'react'
import { AsyncStorage, AppState, NetInfo, Platform, PermissionsAndroid } from 'react-native'
import {observer, inject} from "mobx-react/native"
import SplashScreen from './splash'
import JoinScreen from './join'
import MainNavigator from './navigator'
import {addNavigationHelpers} from "react-navigation";

async function requestPermission() {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        'title': 'Camera Permission',
        'message': 'Artsee needs to access your Camera.'
      }
    )
    console.log('granted', granted);
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera Permitted")
    } else {
      console.log("Camera permission denied")
    }
  } catch (err) {
    console.warn(err)
  }

  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      {
        'title': 'Storage Permission',
        'message': 'Artsee needs to access your Storage.'
      }
    )
    console.log('granted', granted);
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Storage Permitted")
    } else {
      console.log("Storage permission denied")
    }
  } catch (err) {
    console.warn(err)
  }
}

@inject('stateStore', 'authStore', 'sessionStore', 'rootNavigation')
@observer
class Root extends Component {
  constructor() {
    super()
    if(Platform.OS === 'android')
      requestPermission()

    this.state = {
      page: 1
    }
  }

  componentDidMount () {
    AppState.addEventListener('change', this.props.sessionStore.handleAppStateChange);
    NetInfo.getConnectionInfo().then((connectionInfo) => {
      console.log('Initial, type: ' + connectionInfo.type + ', effectiveType: ' + connectionInfo.effectiveType);
    });

    NetInfo.isConnected.addEventListener('connectionChange', this.props.sessionStore.handleConnectionChange);
  }

  componentWillUnmount() {
    console.log('app unmounted')
    NetInfo.isConnected.removeEventListener(
      'connectionChange',
      this.props.sessionStore.handleConnectionChange
    )
  }

  render() {
    const { page } = this.state
    const { state, dispatch, addListener } = this.props.rootNavigation;

    if (!this.props.stateStore.isInit) {
      return <SplashScreen />
    } else {
      return <MainNavigator navigation={addNavigationHelpers({state, dispatch, addListener})}/>
    }
  }
}

export default Root;
