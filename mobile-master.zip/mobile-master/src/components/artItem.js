import React, { Component } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image,
  TouchableHighlight
} from 'react-native';

import StarEmpty from "../images/StarEmpty.png"
import StarFilled from "../images/StarFilled.png"
import StandaloneDisclosureSmall from "../images/StandaloneDisclosureSmall.png"

class ArtItem extends Component {
  render() {
    const {item, index, onPressItem, onFave, hideDelete} = this.props
    // console.log('item', item.id, item.imagePath)
    return (
      <TouchableHighlight onPress={() => onPressItem(item)}>
        <View style={styles.itemContainer}>
          {index % 2 === 0 && item.imagePath
            ? <Image source={{uri: `file://${item.imagePath}`}} style={{height: 164, width: 164, resizeMode: 'cover'}}/>
            : null
          }
          <View style={styles.textWrap}>
            <View>
              <Text
                ellipsizeMode="tail"
                numberOfLines={2}
                style={[styles.textStyle, styles.title]}
              >
                {item.imageName && item.imageName.toUpperCase()}
              </Text>

              {item.artistName
                ? <Text style={[styles.textStyle, styles.artist]}>by {item.artistName}</Text>
                : null
              }
            </View>
            <View>
              <Text
                ellipsizeMode="tail"
                numberOfLines={1}
                style={[styles.textStyle, styles.description]}
              >
                {item.imageDescription}
              </Text>
              {item.height || item.width ? <Text style={[styles.textStyle, styles.description]}>{+Number(item.width || 0).toFixed(2) || ''} x {+Number(item.height || 0).toFixed(2) || ''}</Text> : null}
            </View>
            <TouchableOpacity onPress={() => onFave(item.id)}>
              <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}>
                <Image source={item.isFavorite ? StarFilled : StarEmpty}  style={{marginRight: 4}}/>
                <Text style={{color: item.isFavorite ? '#000' : '#9c9c9c'}}>{item.isFavorite ? 'FAVE' : 'FAVE IT'}</Text>
              </View>
            </TouchableOpacity>
          </View>
          {hideDelete
            ? null
            : (<View style={{marginRight: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}>
              <Image source={StandaloneDisclosureSmall}/>
            </View>)
          }
          {index % 2 !== 0 && item.imagePath
            ? <Image source={{uri: `file://${item.imagePath}`}} style={{height: 164, width: 164, resizeMode: 'cover'}}/>
            : null
          }
        </View>
      </TouchableHighlight>
    )
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
      flexDirection: 'row',
      height: 165,
      borderBottomWidth: 1,
      borderBottomColor: "#000",
      backgroundColor: '#fff'
  },
  textStyle: {
      textAlign: 'center',
      color: '#000'
  },
  textWrap: {
      flexDirection: 'column',
      justifyContent: 'space-around',
      alignItems: 'center',
      flex: 1,
      marginHorizontal: 16,
  },
  title: {
      fontFamily: 'Avenir-Book',
      color: '#343434',
      fontSize: 18,
      textAlignVertical: 'bottom',
      lineHeight: 20,
  },
  artist: {
      fontFamily: 'Georgia',
      fontSize: 13,
      color: '#343434',
      lineHeight: 16
  },
  description: {
      fontFamily: 'Avenir-Book',
      fontSize: 12,
      color: '#343434',
      lineHeight: 14,
  }
});

//make this component available to the app
export default ArtItem;
