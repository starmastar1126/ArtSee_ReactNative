import React from 'react'
import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native'
import { observer, inject } from "mobx-react/native"
import {Icon} from "react-native-elements";

@inject('stateStore', 'authStore')
@observer
export default class DrawerContainer extends React.Component {

  logout = () => {
    this.props.authStore.logout()
    this.props.navigation.navigate('Main')
  }

  render() {
    const { navigation, stateStore } = this.props
    const user = stateStore.user

    return (
      <View style={styles.container}>
        {/*<View style={styles.userWrap}>*/}
          {/*<TouchableOpacity*/}
            {/*style={styles.groupIconButton}*/}
            {/*// onPress={this.handleChooseImage}*/}
          {/*>*/}
            {/*<Image*/}
              {/*style={styles.groupIcon}*/}
              {/*source={stateStore.photo_url ? {uri: stateStore.photo_url} : null}*/}
            {/*/>*/}
          {/*</TouchableOpacity>*/}
          {/*<View style={styles.userWrapName}>*/}
            {/*<Text>{stateStore.displayName}</Text>*/}
            {/*<Text>{stateStore.user && stateStore.user.email}</Text>*/}
            {/*<Text>{stateStore.user && stateStore.user.phone}</Text>*/}
          {/*</View>*/}
        {/*</View>*/}
        <TouchableOpacity
          onPress={() => navigation.popToTop()}
        >
          <View style={styles.menuItem}>
            <Icon
              name='home'
              color="#fff"
              type='simple-line-icon'
              style={styles.itemIcon}
            />
            <Text
              style={styles.itemText}>
              Library
            </Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate('GalleryDirectory')}
        >
          <View style={styles.menuItem}>
            <Icon
              name='list'
              color="#fff"
              type='simple-line-icon'
              style={styles.itemIcon}
            />
            <Text
              style={styles.itemText}>
              Gallery Directory
            </Text>
          </View>
        </TouchableOpacity>
        {this.props.stateStore.isAuthenticated
          ? (<TouchableOpacity
            onPress={() => navigation.navigate('Account')}
          >
            <View style={styles.menuItem}>
              <Icon
                name='user'
                color="#fff"
                type='simple-line-icon'
                style={styles.itemIcon}
              />
              <Text
                style={styles.itemText}>
                Account
              </Text>
            </View>
          </TouchableOpacity>)
          : null
        }
        {this.props.stateStore.isAuthenticated
          ? (<TouchableOpacity
              onPress={() => this.logout()}
            >
              <View style={styles.menuItem}>
                <Icon
                  name='logout'
                  color="#fff"
                  type='simple-line-icon'
                  style={styles.itemIcon}
                />
                <Text
                  style={styles.itemText}>
                  Log Out
                </Text>
              </View>
            </TouchableOpacity>)
          : (<TouchableOpacity
              onPress={() => navigation.navigate('Login')}
            >
              <View style={styles.menuItem}>
                <Icon
                  name='login'
                  color="#fff"
                  type='simple-line-icon'
                  style={styles.itemIcon}
                />
                <Text
                  style={styles.itemText}>
                  Log In
                </Text>
              </View>
            </TouchableOpacity>)
        }
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 30,
    backgroundColor: '#999'
  },
  menuItem: {
    flexDirection: 'row',
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 32,
    borderColor: '#fff',
    borderWidth: 1,
    borderRadius: 3
  },
  itemText: {
    marginLeft: 16,
    fontSize: 18,
    color: '#fff'
  },
  itemIcon: {
    color: '#fff',
  },
  groupIconButton: {
    margin: 16,
    width: 80,
    height: 80,
    borderRadius: 40,
    shadowOffset: {width: 1, height: 2},
    shadowColor: '#000',
    backgroundColor: "#e9e7e7",
    shadowOpacity: 0.3,
  },
  groupIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#fff',
  },
  userWrap: {
    flexDirection: 'row',
    borderColor: '#eee',
    borderBottomWidth: 1,
  },
  userWrapName: {
    flexDirection: 'column',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
  }
})
