import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView, Button } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { size, trim } from 'lodash'
import prompt from 'react-native-prompt-android';
import {backButton} from "./ui";
import {FormInput} from "react-native-elements";

@inject('stateStore', 'authStore')
@observer
class AccountScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params = {} } = navigation.state

    return {
      title: 'Account',
      headerLeft: backButton(navigation),
      headerRight: (<TouchableOpacity
        onPress={params.handleSave}
        disabled={params.disabled}
        style={{marginRight: 16}}
      >
        <Text style={{color: params.disabled ? '#aaa' : '#000'}}>Save</Text>
      </TouchableOpacity>)
    }
  }

  state = {
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phone: '',
  }

  constructor(props) {
    super(props)
  }

  validate = () => {
    const { email } = this.state
    let error = {}

    if (email.trim() === '') {
      error.email = true
    }

    console.log('validate', error)
    return error
  }

  validatePassword = () => {
    const { password, confirmPassword } = this.state
    let error = {}

    if (password === '') {
      error.password = true
    }

    if (confirmPassword === '' || confirmPassword !== password) {
      error.confirmPassword = true
    }
    console.log('validate password', error)
    return error
  }

  submit = () => {
    console.log('register submit')
    const { email, firstName, lastName, phone } = this.state
    const data = { newEmail: email, firstName, lastName, phone }

    this.props.authStore.update(data, (res) => {
      if (res) {
        this.props.navigation.popToTop()
      }
    })
  }

  handleChangeText = (name) => (value) => {
    const newState = {[name]: value}

    this.setState(newState, () => {
      let disabled = true

      if (size(this.validate()) === 0) {
        disabled = false
      }

      this.props.navigation.setParams({ handleSave: this.submit, disabled: disabled });
    })
  }

  handleChangePassword = () => {
    prompt(
      'Change Password',
      "Enter the new password below",
      [
        {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        {text: 'Change', onPress: password => this.props.authStore.changePassword(password)},
      ],
      {
        type: 'plain-text',
        cancelable: false,
        defaultValue: '',
        placeholder: 'New password'
      }
    );
  }

  componentWillMount() {
    this.props.navigation.setParams({ handleSave: this.submit, disabled: false });

    const user = this.props.stateStore.user || {}
    console.log('user', user)
    this.setState({...user})
  }

  render() {
    return (
      <View
        style={styles.container}
        onLayout={(event) => this.setState({
          width : event.nativeEvent.layout.width,
          height : event.nativeEvent.layout.height
        })}
      >
        <View style={styles.section}>
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder="First Name"
            value={this.state.firstName}
            onChangeText={this.handleChangeText('firstName')}
          />
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder="Last Name"
            value={this.state.lastName}
            onChangeText={this.handleChangeText('lastName')}
          />
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder="Email"
            value={this.state.email}
            onChangeText={this.handleChangeText('email')}
          />
          {/*<FormInput*/}
            {/*underlineColorAndroid='transparent'*/}
            {/*containerStyle={styles.containerStyle}*/}
            {/*inputStyle={[styles.inputStyle]}*/}
            {/*placeholder="Password"*/}
            {/*value={this.state.password}*/}
            {/*onChangeText={this.handleChangeText('password')}*/}
          {/*/>*/}
          {/*<FormInput*/}
            {/*underlineColorAndroid='transparent'*/}
            {/*containerStyle={[styles.containerStyle, {borderBottomWidth: 0}]}*/}
            {/*inputStyle={[styles.inputStyle]}*/}
            {/*placeholder="Confirm Password"*/}
            {/*value={this.state.confirmPassword}*/}
            {/*onChangeText={this.handleChangeText('confirmPassword')}*/}
          {/*/>*/}
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={[styles.containerStyle, {borderBottomWidth: 0}]}
            inputStyle={[styles.inputStyle]}
            placeholder="Phone"
            value={this.state.phone}
            onChangeText={this.handleChangeText('phone')}
          />
        </View>
        <View style={{paddingHorizontal: 32}}>
          <TouchableOpacity
            style={styles.linkButton}
            onPress={this.handleChangePassword}
          >
            <Text style={styles.buttonText}>Change Password</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee'
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 40,
    paddingHorizontal: 16,
    borderColor: '#ccc',
    borderBottomWidth: 1,
    borderTopWidth: 1,
  },
  containerStyle: {
    borderColor: '#ccc',
    borderBottomWidth: 1,
    borderRadius: 0,
    // padding: 0,
    margin: 0,
    paddingTop: 0,
    marginTop: 8,
  },
  inputStyle: {
    paddingTop: 0,
    marginTop: 0,
    height: 35,
  },
  linkButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 5,
    paddingVertical: 12,
    width: '100%',
    marginTop: 24,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonText: {
    color: '#000',
    fontSize: 18,
  },
});

//make this component available to the app
export default AccountScreen;
