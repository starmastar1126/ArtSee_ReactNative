//import liraries
import React, { Component } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image, TextInput, Keyboard, ScrollView,
  KeyboardAvoidingView, Dimensions
} from 'react-native';
import {observer, inject} from "mobx-react/native";
import {FormLabel, FormInput, FormValidationMessage} from 'react-native-elements'
import { size } from 'lodash'
import {APP_TITLE, THEME} from "../settings";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";

const ImagePicker = require('react-native-image-picker');
const options = {
  mediaType: 'photo',
  maxWidth: 600,
  maxHeight: 600,
  quality: 1,
  noData: true,
};
const window = Dimensions.get('window')
console.log(window.width, window.height)

// create a component
@inject('stateStore', 'authStore')
@observer
class JoinScreen extends Component {
  constructor() {
    super();

    this.state = {
      photoSource: null,
      name: '',
      email: '',
      password: '',
      passwordConfirm: '',
      phone: '',
      error: {},
      offset: 0
    }
  }

  handleChangeText = (name) => (value) => {
    this.setState({[name]: value.trim()}, () => {
      this.validate()
    })
  }

  validate = () => {
    const { name, password, phone, passwordConfirm, email } = this.state
    let error = {}

    if (name.trim() === '') {
      error.name = true
    }
    if (email.trim() === '') {
      error.email = true
    }
    if (password === '') {
      error.password = true
    }
    if (password !== '' && password !== passwordConfirm) {
      error.passwordConfirm = true
    }
    if (phone.trim() === '') {
      error.phone = true
    }
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
    if (email.trim() !== '' && reg.test(email.trim()) === false) {
      error.email = true
    }

    this.setState({error})
    return error
  }

  submit = () => {
    // console.log('submit', size(this.validate()))
    if (size(this.validate()) === 0) {
      const data = {
        displayName: this.state.name.trim(),
        password: this.state.password,
        phone: this.state.phone.trim(),
        email: this.state.email.trim(),
      }

      this.props.authStore.register(data, this.state.photoSource, (res) => {
        console.log('res', res)
        if (res) {
          this.props.navigation.navigate('Main')
        }
      })
    }
  }

  handleLogin = () => {
    console.log('handleLogin', this.props.navigation && this.props.navigation.state)
    this.props.navigation.navigate('Login')
  }

  handleChooseImage = () => {
    ImagePicker.showImagePicker(options, (response) => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      }
      else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      }
      else {
        let source = { ...response };

        // You can also display the image using data:
        // let source = { uri: 'data:image/jpeg;base64,' + response.data };

        this.setState({
          photoSource: source
        });
      }
    });
  }

  componentWillMount() {
    this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow.bind(this));
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide.bind(this));
  }

  componentWillUnmount() {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  _keyboardDidShow(e) {
    // this.setState({offset: e.endCoordinates.height})
  }

  _keyboardDidHide() {
    // this.setState({offset: 0})
  }

  render() {
    const { offset, error } = this.state

    return (
			<View>
				<View style={[styles.fixed]}>
					<ActivityIndicatorElement width={window.width} height={window.height} />
				</View>
				<KeyboardAwareScrollView style={{position: 'relative'}}>
					<ScrollView scrollEnables={false} style={styles.container}>
						<Text style={styles.terms}>
              {APP_TITLE}
						</Text>
						<View style={{ flex: 1 }} />
						<View style={{ width: '100%', alignItems: 'center', marginBottom: 20 }}>
							<TouchableOpacity
								style={styles.groupIconButton}
								onPress={this.handleChooseImage}
							>
								<Image
									style={styles.groupIcon}
									source={this.state.photoSource}
								/>
							</TouchableOpacity>
							<FormLabel labelStyle={{ fontSize: 20}}>Name</FormLabel>
							<FormInput
								underlineColorAndroid={THEME.primaryColor}
								inputStyle={{textAlign: 'center'}}
								value={this.state.name}
								onChangeText={this.handleChangeText('name')}
							/>
							<FormValidationMessage>{error.name ? 'This field is required' : ''}</FormValidationMessage>
							<FormLabel labelStyle={{ fontSize: 20}}>Email</FormLabel>
							<FormInput
								underlineColorAndroid={THEME.primaryColor}
								inputStyle={{textAlign: 'center'}}
								value={this.state.email}
								keyboardType="email-address"
								onChangeText={this.handleChangeText('email')}
							/>
							<FormValidationMessage>{error.email ? 'Email address not valid' : ''}</FormValidationMessage>
							<FormLabel labelStyle={{ fontSize: 20}}>Password</FormLabel>
							<FormInput
								underlineColorAndroid={THEME.primaryColor}
								inputStyle={{textAlign: 'center'}}
								value={this.state.password}
								secureTextEntry
								onChangeText={this.handleChangeText('password')}
							/>
							<FormValidationMessage>{error.password ? 'This field is required' : ''}</FormValidationMessage>
							<FormLabel labelStyle={{ fontSize: 20}}>Password confirm</FormLabel>
							<FormInput
								underlineColorAndroid={THEME.primaryColor}
								inputStyle={{textAlign: 'center'}}
								value={this.state.passwordConfirm}
								secureTextEntry
								onChangeText={this.handleChangeText('passwordConfirm')}
							/>
							<FormValidationMessage>{error.passwordConfirm ? 'Password does not match the confirm password' : ''}</FormValidationMessage>
							<FormLabel labelStyle={{ fontSize: 20}}>Phone</FormLabel>
							<FormInput
								underlineColorAndroid={THEME.primaryColor}
								inputStyle={{textAlign: 'center'}}
								value={this.state.phone}
								onChangeText={this.handleChangeText('phone')}
							/>
							<FormValidationMessage>{error.phone ? 'This field is required' : ''}</FormValidationMessage>
							<TouchableOpacity
								style={styles.joinButton}
								onPress={this.submit}
							>
								<Text style={styles.buttonText}>Sign Up</Text>
							</TouchableOpacity>
							<TouchableOpacity
								style={styles.link}
								onPress={this.handleLogin}
							>
								<Text style={styles.linkText}>Log In</Text>
							</TouchableOpacity>
						</View>
					</ScrollView>
				</KeyboardAwareScrollView>
			</View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1
    // width: '100%',
    // height: '100%',
    // paddingTop: 20,
    // alignItems: 'center'
  },
  fixed: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  terms: {
    width: '100%',
    padding: 15,
    paddingTop: 30,
    fontSize: 20,
    textAlign: 'center',
    color: "#000",
    fontWeight: "bold"
  },
  joinButton: {
    marginBottom: 20,
    width: '76%',
    height: 50,
    borderRadius: 25,
    backgroundColor: THEME.primaryColor,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
    fontWeight: '500'
  },
  link: {
    marginBottom: 40,
  },
  linkText: {
    fontSize: 20,
  },
  groupIconButton: {
    marginTop: 15,
    marginBottom: 10,
    width: 160,
    height: 160,
    borderRadius: 80,
    shadowOffset: {width: 1, height: 2},
    shadowColor: '#000',
    backgroundColor: "#e9e7e7",
    shadowOpacity: 0.3,
  },
  groupIcon: {
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: '#fff',
  },
});

//make this component available to the app
export default JoinScreen;
