import React, { Component } from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList, Image, TouchableHighlight, Animated, Dimensions} from 'react-native';
import { size, map } from 'lodash'
import moment from 'moment'
import StarEmpty from "../images/StarEmpty.png"
import StarFilled from "../images/StarFilled.png"
import StandaloneDisclosureSmall from "../images/StandaloneDisclosureSmall.png"

const Window = Dimensions.get('window')

class HangupItem extends Component {
  state = {}
  renderArts = (item, index) => {
    return item && item.arts && map(item.arts.slice(), (art, index2) => {
      console.log('art dimentions inch', index, art.width, art.height, item.wall.width, item.wall.height)
      console.log('art dimentions pixels', index, art.x, art.y, art.pixelWidth, art.pixelHeight, item.wall.pixelWidth, item.wall.pixelHeight)
      const k = item.wall.height / art.height
      const kW = Window.width / item.wall.pixelWidth
      const kWHeight = kW * item.wall.pixelHeight
      const kWW = 150 / kWHeight
      console.log('kWHeight', kWHeight, kWW)
      // const k2 = 150 / item.wall.pixelHeight
      const k2 = 150 / Window.height
      const scaleHeight = 150 / k
      console.log('scaleHeight', scaleHeight, k2, item.wall.pixelHeight, k)
      const scaleWidth = art.pixelWidth * scaleHeight / art.pixelHeight

      const scaleX =  kWW * art.x
      const scaleY =  kWW * art.y

      console.log('k', k, k2)
      console.log('scaleWidth', scaleWidth, scaleHeight)
      console.log('scaleX', scaleX, scaleY, art.x, art.y)
      const offsetXStyle = index % 2 === 0 ? {left: 75 + scaleX} : {right: 75 - scaleX - scaleWidth, }
      return (
        <Animated.Image
          key={index2}
          source={{uri: `file://${art.imagePath}`}}
          style={[
            offsetXStyle,
            {
              top: 75 + scaleY ,
              position: 'absolute',
              transform: [{rotateZ: `${art.rotation}deg`},],
              height: scaleHeight || 100,
              width: scaleWidth || 100,
              resizeMode: 'contain'
            }
          ]}
        />
      )
    })
  }

  render() {
    const { item, index, onPressItem, onFave, selectMode } = this.props
    // console.log('renderWall', item, index)
    const imageSource = parseInt(item.wall.imagePath)

    console.log('image', item.imagePath, moment().unix())
    return (
      <TouchableHighlight onPress={() => onPressItem(item)}>
        <View style={styles.itemContainer}
          onLayout={(event) => this.setState({
            width : event.nativeEvent.layout.width,
            height : event.nativeEvent.layout.height
          })}
        >
          {index % 2 === 0 && ((item.wall && item.wall.imagePath) || imageSource)
            ? (<View style={{overflow: 'hidden', position: 'relative', zIndex: 500}}>
              <Image source={{uri: `${item.imagePath}?time=${moment().unix()}`}} style={{height: 164, width: 164, resizeMode: 'cover'}}/>
              {/*<Image source={imageSource > 0 ? imageSource : {uri: `file://${item.wall.imagePath}`}} style={{height: 150, width: 150, resizeMode: 'cover'}}/>*/}
              {/*{this.renderArts(item, index)}*/}
            </View>)
            : null
          }
          <View style={styles.textWrap}>
            <Text
              ellipsizeMode="tail"
              numberOfLines={2}
              style={[styles.textStyle, styles.title]}
            >
              {size(item.arts.slice()) === 1
                ? `${item.arts[0].imageName.toUpperCase()}`
                : size(item.arts.slice()) === 0 ? item.wall && item.wall.wallName && item.wall.wallName.toUpperCase() : 'MULTIPLE PIECES'
              }
            </Text>
            {size(item.arts.slice()) > 0
              ? (<Text style={[styles.textStyle, styles.artist]}>
                {size(item.arts.slice()) === 1
                  ? `by ${item.arts[0].artistName}`
                  : `in ${item.wall && item.wall.wallName && item.wall.wallName.toUpperCase()}`
                }
              </Text>)
              : null
            }
            {onFave
              ? (<TouchableOpacity onPress={() => onFave(item.id)}>
                <View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}>
                  <Image source={item.isFavorite ? StarFilled : StarEmpty}  style={{marginRight: 4}}/>
                  <Text style={{color: item.isFavorite ? '#000' : '#9c9c9c'}}>{item.isFavorite ? 'FAVE' : 'FAVE IT'}</Text>
                </View>
              </TouchableOpacity>)
              : null
            }
          </View>
          {!selectMode
            ? (<View style={{marginRight: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}}>
              <Image source={StandaloneDisclosureSmall}/>
            </View>)
            : null
          }
          {index % 2 !== 0 && ((item.wall && item.wall.imagePath) || imageSource)
            ? (<View style={{overflow: 'hidden', position: 'relative', zIndex: 500}}>
                <Image source={{uri: `${item.imagePath}?time=${moment().unix()}`}} style={{height: 164, width: 164, resizeMode: 'cover'}}/>
              {/*{this.renderArts(item, index)}*/}
            </View>)
            : null
          }

        </View>
      </TouchableHighlight>
    )
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 165,
    borderBottomWidth: 1,
    borderBottomColor: "#000",
    backgroundColor: '#fff'
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  },
  textWrap: {
    flexDirection: 'column',
    justifyContent: 'space-around',
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 16,
  },
  title: {
    fontFamily: 'Avenir-Book',
    color: '#343434',
    fontSize: 18,
    textAlignVertical: 'bottom',
    lineHeight: 20,
  },
  artist: {
    fontFamily: 'Georgia',
    fontSize: 13,
    color: '#343434',
    lineHeight: 16
  },
  description: {
    fontFamily: 'Avenir-Book',
    fontSize: 12,
    color: '#343434',
    lineHeight: 14,
  }
});

//make this component available to the app
export default HangupItem;
