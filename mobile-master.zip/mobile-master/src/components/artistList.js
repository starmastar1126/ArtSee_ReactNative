import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach, map, size } from 'lodash'
import realm from '@store/realm';

import StarEmpty from "../images/StarEmpty.png"
import StarFilled from "../images/StarFilled.png"
import StandaloneDisclosureSmall from "../images/StandaloneDisclosureSmall.png"
import {backButton, closeButton} from "./ui";
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import {THEME} from "../settings";
import {Icon} from "react-native-elements";

@inject('stateStore', 'artStore')
@observer
class ArtistListScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      title: params && params.galleryName || 'Artist List',
      headerLeft: backButton(navigation),
      headerRight: <View style={{marginRight: 16}}>{closeButton(navigation)}</View>
    }
  }

  constructor(props) {
    super(props)
  }

  state = {}

  componentWillMount() {
    const galleryID = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.galleryID

    this.props.artStore.artistList(galleryID);
  }

  renderList = ({item}) => {
    const galleryID = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.galleryID

    return (
      <View style={styles.itemContainer}>
        <View style={styles.symbol}><Text>{item.index}</Text></View>
        {item && item.item && map(item.item.items, (gal, i) => {
          if (gal.artistName) {
            return (<TouchableOpacity key={i} onPress={() => {
              this.props.navigation.navigate('ArtList', {
                galleryID: galleryID,
                artistName: gal.artistName,
                firstName: gal.firstName,
                lastName: gal.lastName,
              })}
            }>
              <View style={[styles.galleryTitle, {borderBottomWidth: i + 1 < size(item.item.items) ? 1 : 0}]}>
                <Text>{gal.artistName}</Text>
                <Icon
                  name={'chevron-right'}
                  type='entypo'
                  color={'#ccc'}
                  iconStyle={{paddingRight: 8}}
                />
              </View>
            </TouchableOpacity>)
          }
        })}
      </View>
    )
  }

  render() {
    console.log('data', this.props.stateStore.artistList.slice())
    return (
      <View
        style={styles.container}
        onLayout={(event) => this.setState({
          width : event.nativeEvent.layout.width,
          height : event.nativeEvent.layout.height
        })}
      >
        <View>
          <FlatList
            keyExtractor={(item) => `${item.index}`}
            data={this.props.stateStore.artistList.slice()}
            renderItem={this.renderList}
          />
        </View>
        <ActivityIndicatorElement width={this.state.width} height={this.state.height} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'column',
  },
  symbol: {
    backgroundColor: '#eee',
    paddingHorizontal: 16,
    paddingVertical: 4
  },
  galleryTitle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomColor: "#ccc",
    marginHorizontal: 16,
    paddingVertical: 8
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  }
});

export default ArtistListScreen;
