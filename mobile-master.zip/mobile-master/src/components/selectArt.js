import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach } from 'lodash'
import realm from '@store/realm';
import { Icon } from "react-native-elements";

import ArtItem from "./artItem";
import {cancelButton} from "./ui";

const ImagePicker = require('react-native-image-picker');
const options = {
  title: '',
  chooseFromLibraryButtonTitle: `Choose from Camera Roll`,
  mediaType: 'photo',
  // maxWidth: 600,
  // maxHeight: 600,
  quality: 1,
  noData: true,
  waitUntilSaved: true,
  cameraRoll: true,
};

@inject('artStore', 'hangupStore')
@observer
class SelectArtScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      title: 'Select Art',
      headerLeft: <View style={{marginRight: 16}}>{cancelButton(navigation, params && params.updateId)}</View>,
      headerRight: <View style={{marginRight: 16}}>
        <TouchableOpacity onPress={params.handleChooseImage}>
          <Icon
            name='plus'
            type='simple-line-icon'
          />
        </TouchableOpacity>
      </View>,
    }
  }

  constructor(props) {
    super(props)
    this.data_source = realm.objects('arts');
    this.data_source.addListener(this.onChange);
  }

  state = {update: false}

  handleChooseImage = () => {
    const { tab } = this.state
    const artOptions = {
      ...options,
      takePhotoButtonTitle: `Take Art Photo`,
      customButtons: [
        {name: 'qrCode', title: 'Scan QR Code'},
      ],
    }

    ImagePicker.showImagePicker(artOptions, (response) => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      }
      else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
        if (response.customButton === 'directory') {
          this.props.navigation.navigate('GalleryDirectory');
        } else if (response.customButton === 'qrCode') {
          this.props.navigation.navigate('QrCodeScanner');
        }
      } else {
        let source = { ...response };

        // You can also display the image using data:
        // let source = { uri: 'data:image/jpeg;base64,' + response.data };

        this.props.navigation.navigate('ArtCreate', {photoSource: source});
      }
    });
  }

  onPressItem = (item) => {
    const { params } = this.props.navigation.state
    const wall = params && params.wall || {}
    const updateId = params && params.updateId

    if (updateId) {
      this.props.navigation.goBack()
      this.props.hangupStore.update(updateId, {art: item}, (res) => {
        console.log('hangupStore.update res', res)
        if (res) {

        }
      })
    } else {
      this.props.navigation.popToTop()
      this.props.hangupStore.create({wall:wall, art: item}, (res) => {
        console.log('hangupStore.create res', res)
        if (res) {
          this.props.navigation.navigate('HangupEdit', {item: res})
        }
      })
    }
  }

  onChange = (name, changes) => {
    console.log('onChange', this.data_source, this.data_source && this.data_source.length, this.data_source && this.data_source.slice())

    // this.setState({update: !this.state.update})
    this.forceUpdate();
  }

  handleFave = (id) => {
    this.props.artStore.toggleFavorit(id)
  }

  onFocus = () => {
    console.log('ArtScreen focus');
    this.forceUpdate();
  }

  componentWillMount() {
    // this.props.artStore.list();
    // realm.objects('arts')
    this.willFocusSubscription = this.props.navigation.addListener('willFocus', this.onFocus)
  }

  componentDidMount() {
    const { params } = this.props.navigation && this.props.navigation.state
    const updateId = params && params.updateId

    this.props.navigation.setParams({handleChooseImage: this.handleChooseImage, updateId})
  }

  componentWillUnmount() {
    this.data_source.removeListener(this.onChange);
    this.willFocusSubscription.remove()
  }

  renderArt = ({item, index}) => {
    return (
      <ArtItem item={item} index={index} onPressItem={this.onPressItem} onFave={this.handleFave}/>
    )
  }

  render() {
    console.log('data_source', this.data_source.length, this.data_source, this.data_source && this.data_source.slice())
    return (
      <View style={styles.container}>
        <View>
          <FlatList
            keyExtractor={(item) => `${item.id}`}
            data={this.data_source.sorted('isFavorite', true).slice()}
            renderItem={this.renderArt}
          />
        </View>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  }
});

//make this component available to the app
export default SelectArtScreen;
