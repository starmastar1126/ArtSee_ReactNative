//import liraries
import React, { Component } from 'react';
import {View, StyleSheet, Text, Modal, Dimensions, TouchableOpacity, Alert, PixelRatio} from 'react-native'
// import { EventRegister } from 'react-native-event-listeners'
import {observer, inject} from "mobx-react/native"
import realm from '@store/realm';
import {Icon, Badge, ButtonGroup} from "react-native-elements";
import HangupsScreen from './hangups'
import ArtScreen from './art'
import WallsScreen from './walls'
// import CommunityScreen from '../community'
// import GroupHome from '../group/home'
// import MyPageScreen from '../mine'
//
// import CreatePost from "../group/createPost";
import ImageResizer from 'react-native-image-resizer';
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import {APP_TITLE, THEME} from "../settings";

const window = Dimensions.get('window')
const ratio = PixelRatio.get()
const ImagePicker = require('react-native-image-picker');
const options = {
  title: '',
  chooseFromLibraryButtonTitle: `Choose from Camera Roll`,
  mediaType: 'photo',
  maxWidth: ratio*window.width*0.8,
  maxHeight: ratio*window.height*0.8,
  quality: 1,
  noData: true,
  waitUntilSaved: true,
  cameraRoll: true,
  // allowsEditing: true
};

const titles = {1: 'Community', 3: 'Groups', 4: 'My Page'}

// create a component
@inject('stateStore')
@observer
class MainScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      // title: title,
      // headerRight: params && params.headerRight || false
    }
  }
  constructor() {
    super()

    this.state = {
      maxHeight : window.height,
      maxWidth : window.width,
      showNav: true,
      tab: 0,
      prevTab: 0,
      modalVisible: false,
    }
  }

  showNav = () => {
    this.setState({showNav: true})
  }

  hideNav = () => {
    this.setState({showNav: false})
  }


  onNavPress = (newTab, force = true) => {
    const {tab} = this.state
    if (tab === newTab && !force) return

    this.setState({tab: newTab, prevTab: this.state.tab})
  }

  // onSelect = data => {
  //   console.log('onSelect', data)
  //   this.setState(data)
  //   this.handleChooseImage()
  // }

  onFocus = (e) => {
    console.log('MainScreen focus', e);
  }

  setModalVisible = (visible = false) => {
    // this.setState({modalVisible: visible});
    this.props.navigation.navigate('CreatePost', {popup: true});
  }

  handleClosePopup = (tab) => {
    this.setModalVisible()

    if (tab !== undefined) {
      this.onNavPress(tab)
    }
  }

  handleChooseImage = () => {
    const { tab } = this.state

    if (tab === 0) {
      this.props.navigation.navigate('SelectWall')
    } else if (tab === 1) {
      const artOptions = {
        ...options,
        takePhotoButtonTitle: `Take Art Photo`,
        customButtons: [
          {name: 'directory', title: 'Add Art from Directory'},
          {name: 'qrCode', title: 'Scan QR Code'},
        ],
      }

      ImagePicker.showImagePicker(artOptions, (response) => {
        console.log('Response = ', response);
        // Alert.alert('Response', JSON.stringify(response))
        if (response.didCancel) {
          console.log('User cancelled image picker');
        }
        else if (response.error) {
          console.log('ImagePicker Error: ', response.error);
        }
        else if (response.customButton) {
          console.log('User tapped custom button: ', response.customButton);
          if (response.customButton === 'directory') {
            this.props.navigation.navigate('GalleryDirectory');
          } else if (response.customButton === 'qrCode') {
            this.props.navigation.navigate('QrCodeScanner');
          }
        } else {
          // let source = { ...response };
          const { error, uri, originalRotation } = response

          // You can also display the image using data:
          // let source = { uri: 'data:image/jpeg;base64,' + response.data };
          if ( uri && !error ) {
            let rotation = 0

            if ( originalRotation === 90 ) {
              rotation = 0
            } else if ( originalRotation === 270 ) {
              rotation = 0
            }

            ImageResizer.createResizedImage( uri, response.width, response.height, "JPEG", 80, rotation ).
            then( ( { uri } ) => {
              console.log('ImageResizer', uri)
              // Alert.alert( 'uri', JSON.stringify(uri))
              this.props.navigation.navigate('ArtCreate', {photoSource: {...response, uri}});
            } ).catch( err => {
              console.log( err )
              return Alert.alert( 'Unable to resize the photo', 'Please try again!' )
            } )
          }


        }
      });
    } else if (tab === 2) {
      const wallOptions = {
        ...options,
        takePhotoButtonTitle: `Take Wall Photo`,
      }

      ImagePicker.showImagePicker(wallOptions, (response) => {
        console.log('Response = ', response);

        if (response.didCancel) {
          console.log('User cancelled image picker');
        }
        else if (response.error) {
          console.log('ImagePicker Error: ', response.error);
        } else if (response.customButton) {
          console.log('User tapped custom button: ', response.customButton);
        }
        else {
          let source = { ...response };

          // You can also display the image using data:
          // let source = { uri: 'data:image/jpeg;base64,' + response.data };

          this.props.navigation.navigate('WallResize', {photoSource: source, onSelect: this.onSelect});
        }
      });
    }

  }

  renderModal = () => {
    return (
      <Modal
        animationType="fade"
        transparent={true}
        visible={this.state.modalVisible}
        onRequestClose={() => {
          this.setModalVisible()
        }}
      >
        <View
          style={{flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)'}}
        >
          <View style={{marginTop: 22, backgroundColor: 'white', width: '85%', height: '85%'}}>
            <CreatePost popup onClose={this.handleClosePopup} />
          </View>
        </View>
      </Modal>
    );
  }

  componentWillMount() {
    // if (!this.props.stateStore.isAuthenticated) {
    //   this.props.navigation.navigate('Login')
    // }

    // this.listener = EventRegister.addEventListener('showNav', (show) => {
    //   this.setState({showNav: show})
    // })

    this.willFocusSubscription = this.props.navigation.addListener('willFocus', this.onFocus)
    // this.onNavPress(0, true)
  }

  componentWillUnmount() {
    // EventRegister.removeEventListener(this.listener)
    this.willFocusSubscription.remove()
  }

  componentWillReact() {
  }

  renderBody() {
    const { tab, prevTab } = this.state

    if (tab === 0) {
      return (<HangupsScreen
          navigation={this.props.navigation}
        />)
    } else if (tab === 1) {
      return (<ArtScreen
          navigation={this.props.navigation}
        />)
    } else if (tab === 2) {
      return (<WallsScreen
        navigation={this.props.navigation}
      />)
    }
  }

  render() {
    const {tab, showNav} = this.state
    const {stateStore} = this.props

    return (
      <View
        style={styles.container}
        onLayout={(event) => this.setState({
          width : event.nativeEvent.layout.width,
          height : event.nativeEvent.layout.height
        })}
      >
        <View style={styles.tabsContainer}>
          <View style={{width: '20%'}}></View>
          <ButtonGroup
            onPress={this.onNavPress}
            selectedIndex={this.state.tab}
            buttons={['Hangups', 'Art', 'Walls']}
            containerStyle={styles.containerStyle}
            buttonStyle={{backgroundColor: '#fff'}}
            textStyle={{color: '#000'}}
            innerBorderStyle={{color: '#000'}}
            selectedButtonStyle={{backgroundColor: '#000'}}
            selectedTextStyle={{color: '#fff'}}
          />
          <View style={styles.addButton}>
            <TouchableOpacity
              onPress={this.handleChooseImage}
            >
              <Icon
                name='plus'
                type='simple-line-icon'
              />
            </TouchableOpacity>

          </View>
        </View>
        {
          this.renderBody()
        }
        {
          // this.renderModal()
        }
        <ActivityIndicatorElement width={this.state.width} height={this.state.height} />
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white'
  },
  containerStyle: {
    height: 26,
    alignSelf: 'center',
    width: '60%',
    borderColor: '#000',
    alignItems: 'center',
    marginRight: 0,
    marginLeft: 0,
  },
  tabsContainer: {
    flexDirection: 'row',
    paddingTop: 4,
    paddingBottom: 3,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  addButton: {
    width: '20%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  }
});

//make this component available to the app
export default MainScreen;
