import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach } from 'lodash'
import realm from '@store/realm';
import { Icon } from "react-native-elements";

import ArtItem from "./artItem";
import {backButton, cancelButton} from "./ui";

@inject('artStore')
@observer
class HangupArtListScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    const { params } = navigation.state

    return {
      title: 'Hangup Artwork',
      headerLeft: backButton(navigation),
    }
  }

  constructor(props) {
    super(props)
  }

  state = {update: false}

  onPressItem = (item) => {
    this.props.navigation.navigate('ArtDetails', {item: item})
  }

  handleFave = (id) => {
    this.props.artStore.toggleFavorit(id)
  }

  renderArt = ({item, index}) => {
    return (
      <ArtItem item={item} index={index} onPressItem={this.onPressItem} onFave={this.handleFave} hideDelete/>
    )
  }

  render() {
    const { params } = this.props.navigation && this.props.navigation.state
    const arts = params && params.item && params.item.arts || []

    const dataSource = []

    forEach(arts, (i) => {
      const item = realm.objectForPrimaryKey('arts', i.artId);
      if (item) {
        dataSource.push(item)
      }
    })

    return (
      <View style={styles.container}>
        <View>
          <FlatList
            keyExtractor={(item) => `${item.id}`}
            data={dataSource}
            renderItem={this.renderArt}
          />
        </View>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  }
});

//make this component available to the app
export default HangupArtListScreen;
