import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView, Button } from 'react-native';
import {observer, inject} from "mobx-react/native"
import realm from '@store/realm';
import {SITE_URL} from "../settings";
import AddHangup from "../images/AddHangup.png"
import Edit from "../images/Edit.png"
import RetouchWall from "../images/RetouchWall.png"
import FullWidthImage from "../common/FullWidthImage";
import {backButton} from "./ui";

@inject('stateStore')
@observer
class WallDetailsScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Wall Details',
      headerLeft: backButton(navigation),
      headerRight: (<TouchableOpacity
        onPress={navigation.state.params.addToHandup}
        style={{marginRight: 16}}
      >
        <Image source={AddHangup}/>
      </TouchableOpacity>)
    }
  }

  constructor() {
    super()
  }

  onFocus = () => {
    console.log('WallDetail focus');
    const item = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.item || {};
    const id = item && item.id

    if (id) {
      const wall = realm.objectForPrimaryKey('walls', id)

      if (wall) {
        console.log('refresh wall item', id, wall)
        this.setState({item: {...wall}})
      }
    }

  }

  addToHandup = () => {
    const item = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.item || {};

    this.props.navigation.navigate('SelectArt', {wall: item})
  }
  
  handleRetouch = () => {
    const photoSource = this.state.item && this.state.item.imagePath

    if (photoSource) {
      this.props.navigation.navigate('WallRetouch', {photoSource})
    }
  }

  handleEdit = (item) => {
    this.props.navigation.navigate('WallCreate', {item: item})
  }

  onPressItem = (item) => {
    this.props.navigation.navigate('ArtDetail', {item: item})
  }

  componentWillMount() {
    const item = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.item || {};
    this.setState({item})
    // this.props.artStore.list();
    this.props.navigation.setParams({ addToHandup: this.addToHandup });
    this.willFocusSubscription = this.props.navigation.addListener('willFocus', this.onFocus)
  }

  componentWillUnmount() {
    this.willFocusSubscription.remove()
  }

  render() {
    const { item = {}} = this.state
    const imageSource = parseInt(item.imagePath)
    console.log('image', item.image)
    return (
      <View style={styles.container}>
        <ScrollView scrollEnables={false} style={styles.container}>
          {item.imagePath || imageSource
            ? (<View style={styles.imageWrap}>
                <Image source={imageSource > 0 ? imageSource : {uri: `file://${item.imagePath}`}} style={{height: 260, width: 'auto', resizeMode: 'contain'}} />
              </View>)
            : null
          }
          <View style={{marginHorizontal: 16}}>
            <Text style={[styles.textStyle, styles.imageTitle]}>
              {item.wallName && item.wallName.toUpperCase()}
            </Text>
            {item.height || item.width ? <Text style={[styles.textStyle, styles.details]}>{+Number(item.width || 0).toFixed(2) || ''} x {+Number(item.height || 0).toFixed(2) || ''}</Text> : null}

            <Text style={[styles.bottomTextStyle, styles.description]}>
              {item.wallDescription}
            </Text>
          </View>
        </ScrollView>
        <View style={styles.bottomBar}>
          <View style={{flex: 1, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'}}>
            <TouchableOpacity onPress={() => this.handleRetouch()} style={{marginRight: 8}}>
              <Image source={RetouchWall}/>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.handleEdit(item)}>
              <Image source={Edit}/>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  imageWrap: {
      marginVertical: 28,
  },
  imageTitle: {
      fontFamily: 'Avenir-Book',
      color: '#343434',
      fontSize: 21,
      lineHeight: 24,
  },
  details: {
      fontFamily: 'Georgia',
      fontSize: 14,
      lineHeight: 16,
      color: '#343434',
      marginTop: 21,
  },
  description: {
      fontFamily: 'Avenir-Book',
      fontSize: 13,
      color: '#343434',
      lineHeight: 16,
      marginTop: 21,
  },
  bottomBar: {
    height: 40,
    borderTopWidth: 1,
    borderTopColor: '#000',
    flexDirection: 'row'
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  },
  bottomTextStyle: {
    fontSize: 14,
    color: '#000'
  },
  contact: {
    color: '#e53935'
  }
});

//make this component available to the app
export default WallDetailsScreen;
