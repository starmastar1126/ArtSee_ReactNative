import React from 'react'
import {observable, action, autorun} from 'mobx';
import { Platform, ToastAndroid, Dimensions } from 'react-native';
import Toast from "react-native-simple-toast";

const window = Dimensions.get('window')

class UIStore {
  optionsAvatarImagePicker = {
    // title: '',  // TODO remove title later
    // cancelButtonTitle: '', // TODO remove button later
    quality: 1.0,
    maxWidth: 900,
    maxHeight: 900,
    // storageOptions: {
    //   skipBackup: true
    // }
    // customButtons: [{
    //   name: 'import', title: 'Import File From'
    // }]
  }

  @observable isLoading = false // Loading indicator
  @observable formErrors = null; // form errors
  @observable width = window.width // TODO
  @observable height = window.height // TODO

  constructor () {
    autorun(() => {console.log('isLoading', this.isLoading)})
    autorun(() => {console.log('Form errors', this.formErrors)})
  }

  @action clearStore = () => {
    this.formErrors = null
    this.isLoading = false
    this.drawerActiveScreen = 'Dashboard',
    this.activeTab = 0
  }

  @action setFormErrors = (value = null) => {
    this.formErrors = value
  }

  /**
   * Show error
   * @param error
   */
  @action showError = (error, value = true) => {
    this.formErrors = value

    this.isLoading = false

    Toast.show(error);
  }

  /**
   * Show notification
   * @param error
   */
  @action showNotification = (message) => {
    this.isLoading = false

    Toast.show(message);
  }

  /**
   * Show notification if No Connect
   * @param error
   */
  @action noConnect = () => {
    this.isLoading = false

    Toast.show('No connection');
  }
}
export default new UIStore();