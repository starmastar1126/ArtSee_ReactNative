import {action, runInAction, autorun} from 'mobx'
import { AsyncStorage, Platform, Alert } from "react-native";
import axios from 'axios'
import { findIndex, find, forEach } from 'lodash'
import RNFetchBlob from 'react-native-fetch-blob'
import UUIDGenerator from 'react-native-uuid-generator';
import stateStore from '@store/state'
import uiStore from '@store/ui'
import realm from '@store/realm';
import {API_URL, SITE_URL} from "../settings";
import Room1 from '../images/Room1.jpg'
import Room2 from '../images/Room2.jpg'
import Room3 from '../images/Room3.jpg'
import Room4 from '../images/Room4.jpg'

const walls = [
  {
    height: 103.51,
    width: 138.01,
    wallName: "Den",
    wallDescription: "A sample room.",
    pixelHeight: 1152,
    pixelWidth: 1536,
    image: Room3,
  },
  {
    height: 113.28,
    width: 151.05,
    wallName: "Living Room 1",
    wallDescription: "A sample room.",
    pixelHeight: 1152,
    pixelWidth: 1536,
    image: Room1,
  },
  {
    height: 168.18,
    width: 221.36,
    wallName: "Living Room 2",
    wallDescription: "A sample room.",
    pixelHeight: 1152,
    pixelWidth: 1536,
    image: Room2,
  },
  {
    height: 108.8,
    width: 105.25,
    wallName: "Hearth Room",
    wallDescription: "A sample room.",
    pixelHeight: 1152,
    pixelWidth: 1536,
    image: Room4,
  }
]

class WallStore {
  constructor () {
    // Create directory for Wall pictures
    RNFetchBlob.fs.mkdir(`${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/`)
      .then(() => {  })
      .catch((err) => {  })

    autorun(() => {
      if (stateStore.isConnected) {
        console.log('wall load')
        AsyncStorage.getItem('wallLoaded')
          .then(json => {
            console.log('wallLoaded get', json);
            stateStore.wallLoaded = json === 'true'

            if (json !== 'true') {
              console.log('LOAD WALLS')
              this.load()
            }
          })
          .catch(error => {console.log('wallLoaded error', error); stateStore.wallLoaded = false });
      }
    })
  }

  /**
   * Create Wall
   */
  @action create = (data, photo, cb) => {
    UUIDGenerator.getRandomUUID((uuid) => {
      // const payload = {...data, username: stateStore.user.username}
      console.log('photo', uuid, photo, data)

      const PATH_TO_WRITE = Platform.OS === 'ios'
        ? (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
        : (photo && photo.fileName ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.fileName}` : '')
      const record = {
        ...data,
        id: uuid,
        width: Number(data.width),
        height: Number(data.height),
        pixelWidth: photo.width,
        pixelHeight: photo.height,
        imagePath: PATH_TO_WRITE,
        // imageName: photo.fileName || '',
      }

      console.log('wall create', record)
      try {
        realm.write(() => {
          realm.create('walls', record, true);
          // fsStore.scanFile(record.imagePath)
          let PATH_FROM = ''

          if (Platform.OS === 'ios') {
            if (photo.uri) {
              PATH_FROM = photo.uri.replace('file://', '')
            }
          } else {
            if (photo.path && photo.fileName) {
              PATH_FROM = photo.path
            }
          }

          console.log('PATH_FROM', PATH_FROM)
          console.log('PATH_TO_WRITE', PATH_TO_WRITE)

          if (PATH_FROM) {
            RNFetchBlob.fs.cp(PATH_FROM, PATH_TO_WRITE)
              .then((res) => {
                console.log('move file res', res);
              })
              .catch((error) => {
                console.log('move file error', error)
              })
          }
        });
      } catch (error) {
        console.log('realm create wall', error)
      }
    })
  }

  /**
   * Update Wall
   */
  @action update = (data, cb) => {

      const record = {
        ...data,
        width: Number(data.width),
        height: Number(data.height),
        // pixelWidth: 0,
        // pixelHeight: 0,
      }

      console.log('wall update', record)
      try {
        realm.write(() => {
          realm.create('walls', record, true);
          // fsStore.scanFile(record.imagePath)
        });
      } catch (error) {
        console.log('realm update wall', error)
      }

    if (cb && typeof cb === 'function') {
      cb(true)
    }
  }

  /**
   * Load default walls from DB
   * @param tab
   * @param query
   * @param cb
   * @returns {Promise.<void>}
   */
  @action load = async (cb) => {
    console.log('wall list')

    forEach(walls, (data, index) => {
      UUIDGenerator.getRandomUUID((uuid) => {
        console.log('image', data.image, uuid)

        const record = {
          ...data,
          id: uuid,
          width: parseFloat(data.width),
          height: parseFloat(data.height),
          pixelWidth: data.pixelWidth,
          pixelHeight: data.pixelHeight,
          imagePath: `${data.image}`,
          // imageName: photo.fileName || '',
        }

        try {
          realm.write(() => {
            const art = realm.create('walls', record, true);
          });
        } catch (error) {
          console.log('realm create art error', error)
        }
      })
    })

    AsyncStorage.setItem('wallLoaded', 'true')
      .then(res => {
        console.log('wallLoaded set', true);
        stateStore.wallLoaded = true;
      })
      .catch(error => {
        console.log('wallLoaded error', error);
        stateStore.wallLoaded = false
      });

    if (cb && typeof cb === 'function') {
      cb(true)
    }
  }

  @action delete = (id) => {
    try {
      realm.write(() => {
        const item = realm.objectForPrimaryKey('walls', id);

        if (item) {
          const hangups = realm.objects('hangups').slice()
          const exist = find(hangups, (item) => {return item.wall.id === id})

          if (exist) {
            Alert.alert('Wall Exists in Hangup', 'The wall can`t be deleted from your library because it has been added to a hangup. To remove it from your library first remove it from any hangups.',
              [
                {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
              ],
              { cancelable: true }
            )
          } else {
            realm.delete(item);
          }

        }
      });
    } catch (error) {
      console.log('realm delete wall error', error)
    }
  }

  @action toggleFavorit = (id) => {
    try {
      realm.write(() => {
        const item = realm.objectForPrimaryKey('walls', id);

        if (item) {
          item.isFavorite = !item.isFavorite
        }
      });
    } catch (error) {
      console.log('realm toggle Favorit wall', error)
    }
  }
}

export default new WallStore();