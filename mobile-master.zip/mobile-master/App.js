import React, { Component } from 'react';
import Root from './src/components/root'
import store from '@store'
import {Provider} from "mobx-react/native";
import NavigationStore from 'react-navigation-mobx-helpers'
import MainNavigator from './src/components/navigator'

const rootNavigation = new NavigationStore(MainNavigator)

type Props = {};
export default class App extends Component<Props> {
  render() {
    return (
      <Provider rootNavigation={rootNavigation} {...store}>
        <Root />
      </Provider>
    );
  }
}
