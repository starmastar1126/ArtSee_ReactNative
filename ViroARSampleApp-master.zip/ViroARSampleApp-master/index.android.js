import { AppRegistry } from 'react-native';
import App from './App.js';

AppRegistry.registerComponent('ViroSampleAR', () => App);

// The below line is necessary for use with the TestBed App
AppRegistry.registerComponent('ViroSample', () => App);