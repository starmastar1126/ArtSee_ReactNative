import React, { Component } from 'react';
import Root from './src/components/root'
import store from '@store'
import { Provider } from "mobx-react/native";
import NavigationStore from 'react-navigation-mobx-helpers'
import MainNavigator from './src/components/navigator'
import { I18nextProvider, withNamespaces } from 'react-i18next'
import i18n from './src/i18n/i18n';

const rootNavigation = new NavigationStore(MainNavigator)

type Props = {};
@withNamespaces()
export default class App extends Component<Props> {
  render() {
    return (
      <Provider rootNavigation={rootNavigation} {...store}>
        <I18nextProvider i18n={i18n}>
          <Root />
        </I18nextProvider>
      </Provider>
    );
  }
}
