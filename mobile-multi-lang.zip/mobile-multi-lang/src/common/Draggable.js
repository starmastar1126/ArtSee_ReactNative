/**
 *	* https://github.com/tongyy/react-native-draggable
 *
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  View,
  Text,
  Image,
  PanResponder,
  Animated,
  Dimensions,
  TouchableWithoutFeedback
} from 'react-native';
import PropTypes from 'prop-types';

let Window = Dimensions.get('window');

export default class Draggable extends Component {
  static propTypes = {
    renderText:PropTypes.string,
    renderShape:PropTypes.string,
    renderSize:PropTypes.number,
    imageSource:PropTypes.oneOfType([
      PropTypes.shape({
        uri: PropTypes.string,
      }),
      PropTypes.number
    ]),
    offsetX:PropTypes.number,
    offsetY:PropTypes.number,
    renderColor:PropTypes.string,
    reverse:PropTypes.bool,
    pressDrag:PropTypes.func,
    onMove:PropTypes.func,
    pressDragRelease:PropTypes.func,
    longPressDrag:PropTypes.func,
    pressInDrag:PropTypes.func,
    pressOutDrag:PropTypes.func,
    z:PropTypes.number,
    x:PropTypes.number,
    y:PropTypes.number

  };

  componentWillMount() {
    const { pressDragRelease, reverse, onMove, offsetX, offsetY } = this.props;
    this._animatedValue = new Animated.ValueXY({x: offsetX  , y: offsetY })
    this._value = {x:  offsetX, y: offsetY}
    this._animatedValue.addListener((value) => this._value = value);

    this.panResponder = PanResponder.create({
      onMoveShouldSetPanResponder: (evt, gestureState) => true,
      onMoveShouldSetPanResponderCapture: (evt, gestureState) => true,
      onPanResponderGrant: (e, gestureState) => {
        if(reverse == false) {
          this._animatedValue.setOffset({x:  this._value.x, y:  this._value.y});
          this._animatedValue.setValue({x: 0 , y:  0});
        }
      },
      onPanResponderMove: Animated.event([null,{
        dx: this._animatedValue.x,
        dy: this._animatedValue.y
      }], {listener: onMove}),
      onPanResponderRelease: (e, gestureState) => {
        let Window = Dimensions.get('window');
        if(pressDragRelease)
          pressDragRelease(e, gestureState, this._value);

        this._animatedValue.flattenOffset();
      }
    });
  }
  componentWillUnmount() {
    this._animatedValue.removeAllListeners();
  }
  constructor(props, defaultProps) {
    super(props, defaultProps);
  }

  render() {
    const { pressDrag, longPressDrag, pressInDrag, pressOutDrag, children } = this.props;

    return (
        <Animated.View
          {...this.panResponder.panHandlers}
          style={[{zIndex: 999, position: 'absolute',}, {transform: this._animatedValue.getTranslateTransform()}]}
        >
          <TouchableWithoutFeedback
            onPress={pressDrag}
            onLongPress={longPressDrag}
            onPressIn={pressInDrag}
            onPressOut={pressOutDrag}
          >
            {children}
          </TouchableWithoutFeedback>
        </Animated.View>
    );
  }
}
