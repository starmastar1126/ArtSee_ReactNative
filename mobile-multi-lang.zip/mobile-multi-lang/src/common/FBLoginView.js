import React, { Component } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import { withNamespaces } from 'react-i18next'

/**
 Example FBLoginView class
 Please note:
 - this is not meant to be a full example but highlights what you have access to
 - If you use a touchable component, you will need to set the onPress event like below
 **/
class FBLoginView extends Component {
  static contextTypes = {
    isLoggedIn: PropTypes.bool,
    login: PropTypes.func,
    logout: PropTypes.func,
    props: PropTypes.shape({})
  };

  constructor(props) {
    super(props);
  }

  render(){
    return (
      <TouchableOpacity
        style={[styles.linkButton, {width: this.props.width}]}
        onPress={() => {
          if(!this.context.isLoggedIn){
            this.context.login()
          }else{
            this.context.logout()
          }
        }}
      >
        <Text style={styles.buttonText}>{this.props.t('btn_fblogin')}</Text>
      </TouchableOpacity>
    )
  }
}

const styles = StyleSheet.create({
  linkButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#fff',
    borderRadius: 5,
    paddingVertical: 12,
    marginTop: 24,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
});

export default withNamespaces('common')(FBLoginView);