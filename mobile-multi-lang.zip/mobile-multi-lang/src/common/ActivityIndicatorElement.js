import React, { Component } from 'react';
import { ActivityIndicator, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import {observer, inject} from "mobx-react/native"
import {THEME} from "../settings";

@inject('stateStore')
@observer
class ActivityIndicatorElement extends Component {
  render() {
    const { width, height } = this.props
    const animating = this.props.stateStore.isLoading
    const isPortrait = height > width

    return animating ? (
      <View
        style = {{
          position: 'absolute',
          width: 40,
          height: 40,
          borderRadius: 20,
          display: 'flex',
          zIndex: 999,
          justifyContent: 'center',
          alignItems: 'center',
          top: (height - 40) / 2,
          left: (width - 40) / 2,
          backgroundColor: 'white'
        }}
      >
        <ActivityIndicator
          animating={animating}
          color={THEME.primaryColor}
          size="large"
          style={styles.activityIndicator}/>
      </View>
    ) : null
  }
}
export default ActivityIndicatorElement

const styles = StyleSheet.create ({
  activityIndicator: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  }
})