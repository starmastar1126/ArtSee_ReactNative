import React, { Component } from 'react';
import { size } from 'lodash'
import {View, Text, StyleSheet, TouchableOpacity, TextInput, Keyboard, ScrollView, Image, Platform} from 'react-native';
import { observer, inject } from "mobx-react/native"
import { FormLabel, FormInput, FormValidationMessage } from 'react-native-elements'
import prompt from 'react-native-prompt-android';
import logo from '../images/AHLogo2x.png'
import {APP_TITLE, THEME} from "../settings";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import bg from '../images/FrontBG2x.png'
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import {FBLogin, FBLoginManager} from 'react-native-facebook-login';
import FBLoginView from '../common/FBLoginView'
import { withNamespaces } from 'react-i18next'

@inject('stateStore', 'authStore', 'uiStore')
@observer
class LoginScreen extends Component {
  static navigationOptions = {
    header: null,
  }

  constructor(props) {
    super(props);

    this.state = {
    	username: '',
    	password: '',
      error: {},
      offset: 0
    }
  }

	handleChangeText = (name) => (value) => {
  	this.setState({[name]: value.trim()}, () => {
      // this.validate()
		})
	}

	validate = () => {
  	const { username, password } = this.state
  	let error = {}

  	if (username.trim() === '') {
			error.username = true
    }
    if (password.trim() === '') {
  		error.password = true
		}

    // this.setState({error})
		return error
	}

	handleLogin = () => {
    if (size(this.validate()) === 0) {
      this.props.authStore.login(this.state.username.trim(), this.state.password, (res) => {
        console.log('res', res)
        if (res) {
          this.props.navigation.goBack()
        }
      });

      // this.props.authStore.login(this.state.username.trim(), this.state.password, (res) => {
      	// console.log('res', res)
      	// if (res) {
      	// 	this.props.navigation.navigate('Main')
			// 	}
			// });
    }
	}
  handleFacebook = (facebookId, profile = {}) => {
  	this.props.authStore.loginFacebook(facebookId, profile, (res) => {
      if (res) {
      	this.props.navigation.goBack()
      }
		})
	}

	handleSignUp = () => {
    this.props.navigation.navigate('SignUp')
	}

  handleCancel = () => {
    this.props.navigation.goBack()
	}

  handleForgotPassword = () => {
    prompt(
      this.props.t("reset_pwd"),
      this.props.t("reset_pwd_desc"),
      [
        {text: this.props.t("btn_cancel"), onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        {text: this.props.t("btn_reset"), onPress: email => this.props.authStore.resetPassword(email)},
      ],
      {
        type: 'plain-text',
        cancelable: false,
        defaultValue: '',
        placeholder: this.props.t("email_address")
      }
    );
	}

	componentWillMount() {
		this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow.bind(this));
		this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide.bind(this));
	}

	componentWillUnmount() {
		this.keyboardDidShowListener.remove();
		this.keyboardDidHideListener.remove();
	}

	_keyboardDidShow(e) {
    // this.setState({offset: e.endCoordinates.height})
	}

	_keyboardDidHide() {
		// this.setState({offset: 0})
	}

	render() {
    const { offset, error } = this.state
    const _this = this

		return (
			<View
				style={{
					flex: 1,
					backgroundColor: '#ccc',
					paddingHorizontal: 32,
					paddingVertical: 0,
					marginBottom: 0
				}}
				onLayout={(event) => this.setState({
					width : event.nativeEvent.layout.width,
					height : event.nativeEvent.layout.height
				})}
			>
				<View
					style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
				>
					<Image
						style={{
              flex: 1,
              resizeMode: 'cover',
            }}
						source={bg}
					/>
				</View>
				<KeyboardAwareScrollView style={{flex: 1}}>
					<View style={{flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
						<View style={styles.logoWrap}>
							<Image resizeMethod="resize" source={logo} style={{width: '100%', height: 80, resizeMode: 'contain'}}/>
						</View>
						<View style={{ width: '100%', alignItems: 'center', marginBottom: 20 }}
							onLayout={(event) => this.setState({
								width2 : event.nativeEvent.layout.width,
								height2 : event.nativeEvent.layout.height
							})}
						>
							<TextInput
								style={styles.loginField}
								placeholder={this.props.t("email_address")}
								underlineColorAndroid='transparent'
								inputStyle={styles.inputText}
								value={this.state.username}
								onChangeText={this.handleChangeText('username')}
							/>
							<TextInput
								style={styles.loginField}
								underlineColorAndroid='transparent'
								placeholder={this.props.t("password")}
								inputStyle={styles.inputText}
								secureTextEntry
								value={this.state.password}
								onChangeText={this.handleChangeText('password')}
							/>
							<TouchableOpacity
								style={styles.loginButton}
								onPress={this.handleLogin}
							>
								<Text style={styles.loginText}>{this.props.t("upper_login")}</Text>
							</TouchableOpacity>
							<FBLogin
								style={Platform.OS === 'ios' ? {marginTop: 24} : {}}
								buttonView={<FBLoginView width={this.state.width2}/>}
								ref={(fbLogin) => { this.fbLogin = fbLogin }}
								loginBehavior={FBLoginManager.LoginBehaviors.Native}
								permissions={["email","user_friends"]}
								onLogin={function(data){
                  console.log("Logged in!");
                  console.log(data);
                  const facebookId = data && data.credentials && data.credentials.userId
                  const profile = data && data.profile
									_this.handleFacebook(facebookId, profile)
                }}
								onLogout={function(){
                  console.log("Logged out.");
                }}
								onLoginFound={function(data){
                  console.log("Existing login found.");
                  console.log(data);
                  const facebookId = data && data.credentials && data.credentials.userId
                  _this.handleFacebook(facebookId)
                }}
								onLoginNotFound={function(){
                  console.log("No user logged in.");
                }}
								onError={function(data){
                  console.log("ERROR");
                  console.log(data);
                }}
								onCancel={function(){
                  console.log("User cancelled.");
                }}
								onPermissionsMissing={function(data){
                  console.log("Check permissions!");
                  this.props.uiStore.showError(this.props.t("msg_fb_permission"))
                  console.log(data);
                }}
							/>
							<TouchableOpacity
								style={styles.linkButton}
								onPress={this.handleSignUp}
							>
								<Text style={styles.buttonText}>{this.props.t("signup")}</Text>
							</TouchableOpacity>
							<TouchableOpacity
								style={styles.linkButton}
								onPress={this.handleCancel}
							>
								<Text style={styles.buttonText}>{this.props.t("btn_cancel")}</Text>
							</TouchableOpacity>

						</View>

						<TouchableOpacity
							style={styles.link}
							onPress={this.handleForgotPassword}
						>
							<Text style={styles.linkText}>{this.props.t("forgot_pwd")}</Text>
						</TouchableOpacity>
					</View>
				</KeyboardAwareScrollView>
				<ActivityIndicatorElement width={this.state.width} height={this.state.height} />
			</View>
		);
	}
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    paddingTop: 20,
    alignItems: 'center'
  },
  logoWrap: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
	marginVertical: 16
  },
  loginField: {
  	backgroundColor: '#eee',
	borderRadius: 5,
	borderColor: '#999',
	borderWidth: 1,
	paddingHorizontal: 16,
  	paddingVertical: 12,
	width: '100%',
	marginBottom: 8,
	fontSize: 18
	},
  loginButton: {
  	backgroundColor: '#ddd',
	borderRadius: 5,
	borderWidth: 0,
	paddingVertical: 12,
	width: '100%',
	marginTop: 8,
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center'
	},
  loginText: {
    fontSize: 18,
    color: '#666'
  },
  linkButton: {
  	backgroundColor: 'transparent',
	borderWidth: 1,
	borderColor: '#fff',
	borderRadius: 5,
	paddingVertical: 12,
	width: '100%',
	marginTop: 24,
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'center'
	},
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
  link: {
	padding: 8,
	margin: 0,
	alignSelf: 'center'
  },
  linkText: {
    fontSize: 14,
	color: '#fff'
  },
	inputText: {
    textAlign: 'left',
	paddingHorizontal: 12,
	marginHorizontal: 16
	},
});

export default withNamespaces('common')(LoginScreen)