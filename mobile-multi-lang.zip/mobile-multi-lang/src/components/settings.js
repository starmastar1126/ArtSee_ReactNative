//import liraries
import React, { Component } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Switch, Slider, Dimensions } from 'react-native';
import { observer, inject } from "mobx-react/native"
import images from '../utils/images'
import {THEME, MIN_RADIUS_VALUE, MAX_RADIUS_VALUE} from "../settings";
import {backButton} from "./ui";
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import { withNamespaces } from 'react-i18next'

var ImagePicker = require('react-native-image-picker');

const options = {
  mediaType: 'photo',
  maxWidth: 600,
  maxHeight: 600,
  quality: 1,
  noData: true,
};

const window = Dimensions.get('window')

// create a component
@inject('stateStore', 'authStore', 'uiStore')
@observer
class SettingsScreen extends Component {
  static navigationOptions = ({ navigation, screenProps: { t } }) => {
    const { params } = navigation.state

    return {
      title: t("settings"),
      headerLeft: backButton(navigation)
    }
  }

  constructor(props) {
    super(props)

    const settings = props.stateStore.user && props.stateStore.user.settings || {}

    this.state = {
      notifyMyPost: settings.notifyMyPost || false,
      notifyComment: settings.notifyComment || false,
      notifyFollow: settings.notifyFollow || false,
      nearbyRadius: settings.nearbyRadius || MIN_RADIUS_VALUE,
      update: new Date().getTime()
    }
  }

  handleChooseImage = () => {
    ImagePicker.showImagePicker(options, (response) => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      }
      else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      }
      else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      }
      else {
        // let source = { ...response };

        // You can also display the image using data:
        // let source = { uri: 'data:image/jpeg;base64,' + response.data };

        this.props.authStore.updatePhoto(response.uri, undefined, (res) => {
          console.log('res', res)
          if (res) {
            this.props.uiStore.showNotification(this.props.t("photo_updated"))
          }
          // this.setState({update: new Date().getTime()})
          // this.props.stateStore.avatarUpdate = !this.props.stateStore.avatarUpdate
        })
      }
    });
  }

  onSave(field) {
    const settings = { ...this.state, ...field}
    console.log('onSave', field, settings)
    this.props.authStore.settings(settings)
    this.setState({...settings})
    // this.props.navigation.goBack()
  }

  componentDidMount() {
    this.props.stateStore.isLoading = false
  }

  renderSettingItem(label, status, onChange) {
    return (
      <View style={styles.settingItem}>
        <Text style={styles.settingItemText}>{label}</Text>
        <Switch
          value={status}
          onValueChange={onChange}
          onTintColor={THEME.primaryDarkColor}
          thumbTintColor={THEME.primaryLightColor}
        />
      </View>
    )
  }

  render() {
    const { notifyMyPost, notifyComment, notifyFollow } = this.state
    const { stateStore } = this.props
    const user = stateStore.user

    return (
      <View style={{flex: 1}}>
        <View style={[styles.fixed]}>
          <ActivityIndicatorElement width={window.width} height={window.height} />
        </View>
        <ScrollView scrollEnabled={false} contentContainerStyle={styles.container}>
          <View style={{width: '100%', flex: 1}}>
            <View style={{ width: '100%', alignItems: 'center', marginBottom: 20 }}>
              <TouchableOpacity
                style={styles.groupIconButton}
                onPress={this.handleChooseImage}
              >
                <Image
                  style={styles.groupIcon}
                  source={stateStore.photo_url ? {uri: stateStore.photo_url} : null}
                />
              </TouchableOpacity>
            </View>
            <View style={styles.settingHeader}>
              <Text style={styles.settingHeaderText}>{this.props.t("notifications")}</Text>
            </View>
            {
              this.renderSettingItem(this.props.t("myposts"), notifyMyPost, (e) => {this.onSave({notifyMyPost: e})})
            }
            {
              this.renderSettingItem(this.props.t("commented_posts"), notifyComment, (e) => {this.onSave({notifyComment: e})})
            }
            {
              this.renderSettingItem(this.props.t("followed_posts"), notifyFollow, (e) => {this.onSave({notifyFollow: e})})
            }
            <View style={styles.settingItem}>
              <Text style={styles.settingItemText}>{this.props.t("nearby_radius")}</Text>
              <Slider
                style={{ flex: 1 }}
                step={MIN_RADIUS_VALUE}
                minimumValue={MAX_RADIUS_VALUE}
                maximumValue={25}
                minimumTrackTintColor={THEME.primaryDarkColor}
                thumbTintColor={THEME.primaryLightColor}
                value={this.state.nearbyRadius || MIN_RADIUS_VALUE}
                onValueChange={val => this.onSave({ nearbyRadius: val })}
                // onSlidingComplete={ val => this.getVal(val)}
              />
              <Text style={styles.settingItemText}>{this.state.nearbyRadius || MIN_RADIUS_VALUE} miles</Text>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    position: 'relative'
  },
  fixed: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  header: {
    width: '100%',
    height: 40,
    borderRadius: 5,
    marginBottom: 5,
    shadowOffset: {width: 0, height: 5},
    shadowColor: '#000',
    shadowOpacity: 0.3,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 10,
    paddingRight: 10
  },
  headerBackButton: {
    width: 15,
    height: 15,
  },
  headerTitle: {
    color: THEME.primaryColor,
    fontSize: 18,
  },
  settingHeader: {
    width: '100%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center'
  },
  settingHeaderText: {
    fontSize: 18,
    fontWeight: 'bold'
  },
  settingItem: {
    width: '100%',
    height: 45,
    paddingLeft: 10,
    paddingRight: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  settingItemText: {
    fontSize: 17,
  },
  saveButton: {
    width: 180,
    height: 45,
    borderRadius: 5,
    backgroundColor: THEME.primaryColor,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 65,
    alignSelf: 'center'
  },
  saveButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold'
  },
  groupIconButton: {
    marginTop: 15,
    marginBottom: 10,
    width: 160,
    height: 160,
    borderRadius: 80,
    shadowOffset: {width: 1, height: 2},
    shadowColor: '#000',
    backgroundColor: "#e9e7e7",
    shadowOpacity: 0.3,
  },
  groupIcon: {
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: '#fff',
  },
});

//make this component available to the app
export default withNamespaces('common')(SettingsScreen)