import React, { Component } from 'react'
import { AsyncStorage, AppState, NetInfo, PermissionsAndroid } from 'react-native'
import {observer, inject} from "mobx-react/native"
import SplashScreen from './splash'
import JoinScreen from './join'
import MainNavigator from './navigator'
import {addNavigationHelpers} from "react-navigation";
import { withNamespaces } from 'react-i18next'

async function requestPermission(t) {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        'title': t("camera_permssion"),
        'message': t("camera_permssion_desc")
      }
    )
    console.log('granted', granted);
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera Permitted")
    } else {
      console.log("Camera permission denied")
    }
  } catch (err) {
    console.warn(err)
  }

  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      {
        'title': t("storage_permssion"),
        'message': t("storage_permssion_desc")
      }
    )
    console.log('granted', granted);
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Storage Permitted")
    } else {
      console.log("Storage permission denied")
    }
  } catch (err) {
    console.warn(err)
  }
}

@inject('stateStore', 'authStore', 'sessionStore', 'rootNavigation')
@observer
class Root extends Component {
  constructor(props) {
    super(props)

    requestPermission(props.t)

    this.state = {
      page: 1
    }
  }

  componentDidMount () {
    AppState.addEventListener('change', this.props.sessionStore.handleAppStateChange);
    NetInfo.getConnectionInfo().then((connectionInfo) => {
      console.log('Initial, type: ' + connectionInfo.type + ', effectiveType: ' + connectionInfo.effectiveType);
    });

    NetInfo.isConnected.addEventListener('connectionChange', this.props.sessionStore.handleConnectionChange);
  }

  componentWillUnmount() {
    console.log('app unmounted')
    NetInfo.isConnected.removeEventListener(
      'connectionChange',
      this.props.sessionStore.handleConnectionChange
    )
  }

  render() {
    const { page } = this.state
    const { state, dispatch, addListener } = this.props.rootNavigation;
    const { t } = this.props;
    if (!this.props.stateStore.isInit) {
      return <SplashScreen />
    } else {
      return <MainNavigator navigation={addNavigationHelpers({state, dispatch, addListener})} screenProps={{t}}/>
    }
  }
}
export default withNamespaces('common')(Root)