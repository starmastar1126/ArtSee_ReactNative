import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach, map } from 'lodash'
import realm from '@store/realm';
import { SwipeListView } from 'react-native-swipe-list-view'

import WallItem from "./wallItem";
import { withNamespaces } from 'react-i18next'

@inject('wallStore')
@observer
class WallsScreen extends Component {
  constructor(props) {
    super(props)
    this.data_source = realm.objects('walls').sorted('isFavorite', true);
    this.data_source.addListener(this.onChange);
  }

  closeRow(rowMap, rowKey) {
    if (rowMap[rowKey]) {
      rowMap[rowKey].closeRow();
    }
  }

  deleteRow(rowMap, rowKey) {
    this.closeRow(rowMap, rowKey);
    this.props.wallStore.delete(rowKey)
  }

  onRowDidOpen = (rowKey, rowMap) => {
    setTimeout(() => {
      this.closeRow(rowMap, rowKey);
    }, 3000);
  }

  handleFave = (id) => {
    this.props.wallStore.toggleFavorit(id)
  }

  onPressItem = (item) => {
    this.props.navigation.navigate('WallDetails', {item: item})
  }

  onChange = (name, changes) => {
    console.log('onChange', this.data_source, this.data_source && this.data_source.length, this.data_source && this.data_source.slice())

    this.forceUpdate();
  }

  onFocus = () => {
    console.log('WallsScreen focus');
    this.forceUpdate();
  }

  renderWall = ({item, index}) => {
    return (
      <WallItem item={item} index={index} onPressItem={this.onPressItem} onFave={this.handleFave}/>
    )
  }

  componentWillMount() {
    this.willFocusSubscription = this.props.navigation.addListener('willFocus', this.onFocus)
  }

  componentDidMount() {
  }

  componentWillUnmount() {
    this.willFocusSubscription.remove()
  }

  render() {
    const data = map(this.data_source.slice(), (i) => {return {...i, key: i.id}})

    return (
      <View style={styles.container}>
        <SwipeListView
          useFlatList={true}
          disableRightSwipe
          closeOnRowPress
          closeOnRowBeginSwipe={true}
          data={data}
          renderItem={this.renderWall}
          renderHiddenItem={ (rowData, rowMap) => (
            <View style={styles.rowBack}>
              <TouchableOpacity style={[styles.backRightBtn, styles.backRightBtnRight]} onPress={ _ => this.deleteRow(rowMap, rowData.item.id) }>
                <Text style={styles.backTextWhite}>{this.props.t("btn_delete")}</Text>
              </TouchableOpacity>
            </View>
          )}
          rightOpenValue={-100}
          // onRowDidOpen={this.onRowDidOpen}
        />
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  },
  backTextWhite: {
    fontSize: 18,
    color: '#FFF'
  },
  rowFront: {
    alignItems: 'center',
    backgroundColor: '#CCC',
    borderBottomColor: 'black',
    borderBottomWidth: 1,
    justifyContent: 'center',
    height: 50,
  },
  rowBack: {
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 15,
  },
  backRightBtn: {
    alignItems: 'center',
    bottom: 0,
    justifyContent: 'center',
    position: 'absolute',
    top: 0,
    width: 100
  },
  backRightBtnRight: {
    backgroundColor: 'red',
    right: 0
  },
});

//make this component available to the app
export default withNamespaces('common')(WallsScreen)