import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach, map, size } from 'lodash'
import realm from '@store/realm';

import StarEmpty from "../images/StarEmpty.png"
import StarFilled from "../images/StarFilled.png"
import StandaloneDisclosureSmall from "../images/StandaloneDisclosureSmall.png"
import { closeButton } from "./ui";
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import {THEME} from "../settings";
import {Icon} from "react-native-elements";
import { withNamespaces } from 'react-i18next'

@inject('stateStore', 'artStore')
@observer
class GalleryDirectoryScreen extends Component {
  static navigationOptions = ({ navigation, screenProps: { t } }) => {
    return {
      title: t("gal_directory"),
      headerLeft: <View></View>,
      headerRight: <View style={{marginRight: 16}}>{closeButton(navigation)}</View>
    }
  }

  constructor(props) {
    super(props)
  }

  state = {}

  componentWillMount() {
    this.props.artStore.galleryList();
  }

  renderGallery = ({item}) => {
    return (
      <View style={styles.itemContainer}>
        <View style={styles.symbol}><Text>{item.index}</Text></View>
        {item && item.item && map(item.item.items, (gal, i) => {
          if (gal.galleryName) {
            return (
              <TouchableOpacity key={i} onPress={() => {this.props.navigation.navigate('ArtistList', {galleryID: gal.galleryID, galleryName: gal.galleryName})}}>
                <View style={[styles.galleryTitle, {borderBottomWidth: i + 1 < size(item.item.items) ? 1 : 0}]}>
                  <Text>{gal.galleryName}</Text>
                  <Icon
                    name={'chevron-right'}
                    type='entypo'
                    color={'#ccc'}
                    iconStyle={{paddingRight: 8}}
                  />
                </View>
              </TouchableOpacity>
            )
          }
        })}
      </View>
    )
  }

  render() {
    // console.log('data_source', this.data_source.length, this.data_source, this.data_source && this.data_source.slice())
    console.log('data', this.props.stateStore.galleryDirectory.slice())
    return (
      <View
        style={styles.container}
        onLayout={(event) => this.setState({
          width : event.nativeEvent.layout.width,
          height : event.nativeEvent.layout.height
        })}
      >
        <View>
          <FlatList
            keyExtractor={(item) => `${item.index}`}
            data={this.props.stateStore.galleryDirectory.slice()}
            renderItem={this.renderGallery}
          />
        </View>
        <ActivityIndicatorElement width={this.state.width} height={this.state.height} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'column',
  },
  symbol: {
    backgroundColor: '#eee',
    paddingHorizontal: 16,
    paddingVertical: 4
  },
  galleryTitle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomColor: "#ccc",
    marginHorizontal: 16,
    paddingVertical: 8
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  }
});

export default withNamespaces('common')(GalleryDirectoryScreen)

