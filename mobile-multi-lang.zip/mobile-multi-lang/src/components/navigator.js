import React, { Component } from 'react';
import { DrawerNavigator, StackNavigator } from 'react-navigation'
import { Easing, Animated } from 'react-native'

import stateStore from '@store/state'
import LoginScreen from './login'
import SignUpScreen from './signup'
import AccountScreen from './account'
import MainScreen from './main'
import ArtDetailsScreen from './artDetails'
import ArtCreateScreen from './artCreate'
import WallsScreen from './walls'
import WallDetailsScreen from './wallDetails'
import WallCreateScreen from './wallCreate'
import GalleryDirectoryScreen from './galleryDirectory'
import ArtistListScreen from './artistList'
import ArtListScreen from './artList'
import QrCodeScannerScreen from './qrCodeScanner'
import SelectArtScreen from './selectArt'
import SelectWallScreen from './selectWall'
import WallResizeScreen from './wallResize'
import WallRetouchScreen from './wallRetouch'
import HangupEditScreen from './hangupEdit'
import HangupArtListScreen from './hangupArtList'

import DrawerContainer from "./drawer";
import {THEME} from "../settings";
import {drawerButton} from "./ui";

const MainNavigator = DrawerNavigator({
  mainFlow:{
    screen: StackNavigator({
      Main: {
        screen: MainScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      Login: {
        screen: LoginScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      SignUp: {
        screen: SignUpScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      Account: {
        screen: AccountScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      ArtDetails: {
        screen: ArtDetailsScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      ArtCreate: {
        screen: ArtCreateScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      WallsScreen: {
        screen: WallsScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      WallDetails: {
        screen: WallDetailsScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      WallCreate: {
        screen: WallCreateScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      WallResize: {
        screen: WallResizeScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      WallRetouch: {
        screen: WallRetouchScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      GalleryDirectory: {
        screen: GalleryDirectoryScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      ArtistList: {
        screen: ArtistListScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      ArtList: {
        screen: ArtListScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      QrCodeScanner: {
        screen: QrCodeScannerScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      SelectArt: {
        screen: SelectArtScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      SelectWall: {
        screen: SelectWallScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      HangupEdit: {
        screen: HangupEditScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      HangupArtList: {
        screen: HangupArtListScreen,
        navigationOptions: {
          gesturesEnabled: false
        }
      },
      // Settings: {
      //   screen: SettingsScreen,
      //   navigationOptions: {
      //     gesturesEnabled: false
      //   }
      // },
    }, {
      navigationOptions: ({navigation}) => ({
        headerStyle: {
          backgroundColor: THEME.headerBackground,
          elevation: 0,
          borderBottomWidth: 1,
          borderBottomColor: THEME.headerColor,
          height: 53,
        },
        headerTitleStyle: {
          fontFamily: 'Arial',
          // fontSize: 13,
          color: THEME.headerColor,
          textTransform: 'uppercase'
        },
        headerTintColor: THEME.headerColor,
        title: 'LIBRARY',
        headerLeft: drawerButton(navigation),
        // headerRight: (<Badge containerStyle={{ backgroundColor: THEME.primaryColor, marginRight: 16}}>
        //   <Text style={{color: 'white'}}>{stateStore.tokens}</Text>
        // </Badge>),
      }),
      initialRouteName: 'Main',
      headerMode: 'screen',
      cardStyle: {backgroundColor: 'white'}
    })
  },
}, {
  contentComponent: DrawerContainer,
  // drawerWidth: 200,
  initialRouteName: 'mainFlow',
})

export default MainNavigator;
