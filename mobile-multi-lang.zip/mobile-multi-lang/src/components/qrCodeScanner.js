import React, { Component } from 'react';
import { View } from 'react-native';
import {observer, inject} from "mobx-react/native"
import QRCodeScanner from 'react-native-qrcode-scanner';
import {closeButton} from "./ui";
import { withNamespaces } from 'react-i18next'

@inject('artStore')
@observer
class QrCodeScannerScreen extends Component {
  static navigationOptions = ({ navigation, screenProps: { t } }) => {
    return {
      title: t("scan_qr"),
      headerLeft: <View></View>,
      headerRight: <View style={{marginRight: 16}}>{closeButton(navigation)}</View>,
    }
  }

  onSuccess(e) {
    console.log('code', e.data)
    this.props.artStore.addArtByQrCode(e.data)
    this.props.navigation.goBack()
  }

  render() {
    return (
      <QRCodeScanner
        onRead={this.onSuccess.bind(this)}
      />
    );
  }
}

export default withNamespaces('common')(QrCodeScannerScreen)
