import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView, Button } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { size, trim } from 'lodash'
import {backButton} from "./ui";
import {FormInput} from "react-native-elements";
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import { withNamespaces } from 'react-i18next'

@inject('stateStore', 'authStore')
@observer
class SignUpScreen extends Component {
  static navigationOptions = ({ navigation, screenProps: { t } }) => {
    const { params = {} } = navigation.state

    return {
      title: t("signup"),
      headerLeft: (<TouchableOpacity onPress={() => navigation.goBack()} style={{marginHorizontal: 16}}>
        <Text>{t("btn_cancel")}</Text>
      </TouchableOpacity>),
      headerRight: (<TouchableOpacity
        onPress={params.handleSave}
        disabled={params.disabled}
        style={{marginRight: 16}}
      >
        <Text style={{color: params.disabled ? '#aaa' : '#000'}}>{t("signup")}</Text>
      </TouchableOpacity>)
    }
  }

  state = {
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phone: '',
  }

  constructor(props) {
    super(props)
  }

  validate = () => {
    const { email, password, confirmPassword } = this.state
    let error = {}

    if (email.trim() === '') {
      error.email = true
    }

    if (password === '') {
      error.password = true
    }

    if (confirmPassword === '' || confirmPassword !== password) {
      error.confirmPassword = true
    }
    console.log('validate', error)
    return error
  }

  submit = () => {
    console.log('register submit')
    const { email, password, firstName, lastName, phone } = this.state
    const data = { email, password, firstName, lastName, phone }

    this.props.authStore.register(data, (res) => {
      if (res) {
        this.props.navigation.popToTop()
      }
    })
  }

  handleChangeText = (name) => (value) => {
    const newState = {[name]: value}

    this.setState(newState, () => {
      let disabled = true

      if (size(this.validate()) === 0) {
        disabled = false
      }

      this.props.navigation.setParams({ handleSave: this.submit, disabled: disabled });
    })
  }

  componentWillMount() {
    this.props.navigation.setParams({ handleSave: this.submit, disabled: true });
  }

  render() {
    return (
      <View
        style={styles.container}
        onLayout={(event) => this.setState({
          width : event.nativeEvent.layout.width,
          height : event.nativeEvent.layout.height
        })}
      >
        <View style={styles.section}>
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder={this.props.t("email")}
            value={this.state.email}
            onChangeText={this.handleChangeText('email')}
          />
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder={this.props.t("password")}
            secureTextEntry
            value={this.state.password}
            onChangeText={this.handleChangeText('password')}
          />
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={[styles.containerStyle, {borderBottomWidth: 0}]}
            inputStyle={[styles.inputStyle]}
            placeholder={this.props.t("confirm_pwd")}
            secureTextEntry
            value={this.state.confirmPassword}
            onChangeText={this.handleChangeText('confirmPassword')}
          />
        </View>
        <View style={styles.section}>
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder={this.props.t("first_name")}
            value={this.state.firstName}
            onChangeText={this.handleChangeText('firstName')}
          />
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={styles.containerStyle}
            inputStyle={[styles.inputStyle]}
            placeholder={this.props.t("last_name")}
            value={this.state.lastName}
            onChangeText={this.handleChangeText('lastName')}
          />
          <FormInput
            underlineColorAndroid='transparent'
            containerStyle={[styles.containerStyle, {borderBottomWidth: 0}]}
            inputStyle={[styles.inputStyle]}
            placeholder={this.props.t("phone")}
            value={this.state.phone}
            onChangeText={this.handleChangeText('phone')}
          />
        </View>
        <ActivityIndicatorElement width={this.state.width} height={this.state.height} />
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee'
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 40,
    paddingHorizontal: 16,
    borderColor: '#ccc',
    borderBottomWidth: 1,
    borderTopWidth: 1,
  },
  containerStyle: {
    borderColor: '#ccc',
    borderBottomWidth: 1,
    borderRadius: 0,
    // padding: 0,
    margin: 0,
    paddingTop: 0,
    marginTop: 8,
  },
  inputStyle: {
    paddingTop: 0,
    marginTop: 0,
    height: 35,
  },
});

//make this component available to the app
export default withNamespaces('common')(SignUpScreen)