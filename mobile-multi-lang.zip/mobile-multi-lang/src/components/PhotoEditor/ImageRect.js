// @flow
import moment from "moment";
import * as React from "react";
import {
  StyleSheet, View, Platform, StatusBar, Dimensions, ActivityIndicator, Animated, Alert, TouchableHighlight, Text,
  Image, PixelRatio, ImageEditor
} from "react-native";
import Exif from 'react-native-exif'
import SImage from './SImage'
import Crop from './Crop'
// import testImage from '../test.jpg'

const {width, height} = Dimensions.get("window");
const defaultRect = {
  top: 0,
  left: 0,
  width: width,
  height: height
}

const ratio = PixelRatio.get()
console.log('PixelRatio ', ratio, ratio*width, ratio*height)

export default class ImageRect extends React.Component {

  state = {
    rect: defaultRect,
    ready: false
  }

  position = {
    top: 0,
    bottom: 0,
    left: 0,
    right: 0
  };


  handleChangeSize = (position) => {
    this.position = position
    // console.log('position', position)
  }

  getRealSize = (value) => {
    const { imageHeight, imageWidth, rect } = this.state
    const k = imageWidth / rect.width
    return parseFloat(value) * k
  }

  handleCrop = () => {
    const { getRealSize } = this
    const { rect } = this.state

    // Alert.alert('Position ', JSON.stringify(this.position))
    const cropData = {
      offset: {
        x: (this.position.left > 0 ? this.position.left : 0) * ratio,
        y: (this.position.top > 0 ? this.position.top : 0) * ratio
      },
      size: {
        width: (
          ratio * (rect.width - parseFloat(this.position.left) - parseFloat(this.position.right))
        ),
        height: (
          ratio * (rect.height - parseFloat(this.position.top) - parseFloat(this.position.bottom))
        )
      },
      resizeMode: 'contain',
    };
    console.log('cropData width', ratio, rect.width, parseFloat(this.position.left), parseFloat(this.position.right), ratio * (rect.width - parseFloat(this.position.left) - parseFloat(this.position.right)))
    console.log('cropData height', ratio, rect.height, parseFloat(this.position.top), parseFloat(this.position.bottom), ratio * (rect.height - parseFloat(this.position.top) - parseFloat(this.position.bottom)))

    // const data = Image.resolveAssetSource(testImage);
    // Alert.alert('data ', `${JSON.stringify(this.state.rect)} ${JSON.stringify(cropData)} ${JSON.stringify(this.position)}`)
    console.log('rect ', JSON.stringify(rect))
    console.log('rect ration', rect.left*ratio, rect.top*ratio, rect.width*ratio, rect.height*ratio)
    console.log('cropData ', JSON.stringify(cropData))
    console.log('position crop ', JSON.stringify(this.position))
    console.log('position ratio ', this.position.top*ratio, this.position.bottom*ratio, this.position.left*ratio, this.position.right*ratio)
    ImageEditor.cropImage(
      this.props.photo,
      cropData,
      (croppedUri) => {
        // Alert.alert('Position ', JSON.stringify(croppedUri))
        Image.getSize(croppedUri, (localWidth, localHeight) => {
          this.props.onSubmit({uri: croppedUri, width: localWidth, height: localHeight})
        })
        console.log('croppedUri', JSON.stringify(croppedUri))
      },
      (failure) => {console.log(failure)}
    );
  }

  refreshSize = (props = this.props) => {
    // Alert.alert('Photo ', `${JSON.stringify(props.photo)} ${height} ${width}`)

    console.log('Photo ', JSON.stringify(props.photo), width, height)
    Exif.getExif(props.photo)
      .then(msg => {
        console.warn('OK: ' + JSON.stringify(msg))
        // Alert.alert('Exif', JSON.stringify(msg))
        console.log('Exif', JSON.stringify(msg))
      })
      .catch(msg => console.warn('ERROR: ' + msg))
    Image.getSize(props.photo, (localWidth, localHeight) => {
      const ratioWidth = localWidth/ratio
      const ratioHeight = localHeight/ratio
      const k = localWidth / localHeight
      let newRect = {...this.state.rect}

      console.log('k', k)
      if (ratioWidth > height || ratioHeight > width) {
        const newHeight = k > 0 ? defaultRect.width / k : defaultRect.height
        const newWidth = defaultRect.height * k
        console.log('newHeight, newWidth', newHeight, newWidth)

        if (newHeight < height * 0.8) {
          newRect.height = newHeight
        } else {
          newRect.width = newWidth
        }
        console.log('resize rect', newHeight < height * 0.8, newWidth < width * 0.8)
      } else {
        newRect.width = ratioWidth
        newRect.height = ratioHeight
      }

      // if (newRect.height > 0.8 * height) {
      //   newRect.height =  0.8 * height
      //   newRect.width = newRect.height * k
      // }
      //
      // if (newRect.width > 0.8 * width) {
      //   newRect.width =  0.8 * width
      //   newRect.height = newRect.width / k
      // }

      newRect.top = (height*0.8 - newRect.height) / 2
      newRect.left = (width - newRect.width) / 2

      // Alert.alert('Width, height ', `${width} ${height} ${localWidth} ${localHeight} ${JSON.stringify(newRect)}`)
      console.log('Width, height ', width, height)
      console.log('localWidth, localHeight ', localWidth, localHeight)
      console.log('ratioWidth, ratioHeight ', ratioWidth, ratioHeight)
      console.log('newRect ', JSON.stringify(newRect))
      this.setState({rect: newRect, imageWidth: localWidth, imageHeight: localHeight}, () => {
        setTimeout(() => {
          this.setState({ready: true})
        }, 500)})
      // Alert.alert('Width, height ', `${k} ${width} ${defaultRect.width} ${defaultRect.width / k}`)
    });
  }

  componentWillMount() {
    this.refreshSize()
  }

  render() {
    // const {navigation} = this.props;
    const {photo} = this.props;
    console.log('photo', photo)

    return (
      <View style={styles.container}>
        <Animated.View style={{  ...StyleSheet.absoluteFillObject  }}>
          {this.state.ready ?
            <Crop style={[this.state.rect, styles.filter]} onChange={this.handleChangeSize}>
              <Image
                style={StyleSheet.absoluteFill}
                source={{uri: photo}}
              />
            </Crop>
            : null
          }
        </Animated.View>
        <View style={styles.nav}>
          <TouchableHighlight
            onPress={() => {
              this.props.onSubmit(null);
            }}>
            <Text style={{color: '#fff'}}>Cancel</Text>
          </TouchableHighlight>

          <TouchableHighlight
            onPress={() => {
              this.handleCrop();
            }}>
            <Text style={{color: '#fff'}}>Crop</Text>
          </TouchableHighlight>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-between",
    backgroundColor: "#000",
  },
  image: {
    ...StyleSheet.absoluteFillObject
  },
  filter: {
    position: "absolute",
  },
  nav: {
    position: "absolute",
    left: '10%',
    width: '80%',
    height: 50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    bottom: 0
  }
});
