import React from 'react'
import { StyleSheet, Text, View, Image, TouchableOpacity,AsyncStorage } from 'react-native'
import { observer, inject } from "mobx-react/native"
import { Icon } from "react-native-elements";
import { withNamespaces } from 'react-i18next'
import ModalSelector from 'react-native-modal-selector'
import {LANGUAGES, LANGUAGE_STORAGE_KEY} from '../settings'
import i18n from '../i18n/i18n'

@inject('stateStore', 'authStore')
@observer
class DrawerContainer extends React.Component {

  logout = () => {
    this.props.authStore.logout()
    this.props.navigation.navigate('Main')
  }

  render() {
    const { navigation, stateStore } = this.props
    const user = stateStore.user

    return (
      <View style={styles.container}>
        {/*<View style={styles.userWrap}>*/}
        {/*<TouchableOpacity*/}
        {/*style={styles.groupIconButton}*/}
        {/*// onPress={this.handleChooseImage}*/}
        {/*>*/}
        {/*<Image*/}
        {/*style={styles.groupIcon}*/}
        {/*source={stateStore.photo_url ? {uri: stateStore.photo_url} : null}*/}
        {/*/>*/}
        {/*</TouchableOpacity>*/}
        {/*<View style={styles.userWrapName}>*/}
        {/*<Text>{stateStore.displayName}</Text>*/}
        {/*<Text>{stateStore.user && stateStore.user.email}</Text>*/}
        {/*<Text>{stateStore.user && stateStore.user.phone}</Text>*/}
        {/*</View>*/}
        {/*</View>*/}
        <TouchableOpacity
          onPress={() => navigation.popToTop()}
        >
          <View style={styles.menuItem}>
            <Icon
              name='home'
              color="#fff"
              type='simple-line-icon'
              style={styles.itemIcon}
            />
            <Text
              style={styles.itemText}>
              {this.props.t("library")}
            </Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate('GalleryDirectory')}
        >
          <View style={styles.menuItem}>
            <Icon
              name='list'
              color="#fff"
              type='simple-line-icon'
              style={styles.itemIcon}
            />
            <Text
              style={styles.itemText}>
              {this.props.t("gal_directory")}
            </Text>
          </View>
        </TouchableOpacity>
        <ModalSelector
          data={LANGUAGES}
          initValue="English"
          supportedOrientations={['landscape']}
          accessible={true}
          scrollViewAccessibilityLabel={'Scrollable options'}
          cancelButtonAccessibilityLabel={this.props.t('btn_cancel')}
          onChange={(option) => { 
            i18n.changeLanguage(option.key, ()=>{this.setState({...this.state})})
            AsyncStorage.setItem(LANGUAGE_STORAGE_KEY, option.key)
          }}
          >
          <View style={styles.menuItem}>
            <Icon
              name='language'
              color="#fff"
              type='material-icon'
              style={styles.itemIcon}
            />
            <Text
              style={styles.itemText}>
              {this.props.t("language")}
            </Text>
          </View>
        </ModalSelector>
        {this.props.stateStore.isAuthenticated
          ? (<TouchableOpacity
            onPress={() => navigation.navigate('Account')}
          >
            <View style={styles.menuItem}>
              <Icon
                name='user'
                color="#fff"
                type='simple-line-icon'
                style={styles.itemIcon}
              />
              <Text
                style={styles.itemText}>
                {this.props.t("lbl_account")}
              </Text>
            </View>
          </TouchableOpacity>)
          : null
        }
        {this.props.stateStore.isAuthenticated
          ? (<TouchableOpacity
            onPress={() => this.logout()}
          >
            <View style={styles.menuItem}>
              <Icon
                name='logout'
                color="#fff"
                type='simple-line-icon'
                style={styles.itemIcon}
              />
              <Text
                style={styles.itemText}>
                {this.props.t("logout")}
              </Text>
            </View>
          </TouchableOpacity>)
          : (<TouchableOpacity
            onPress={() => navigation.navigate('Login')}
          >
            <View style={styles.menuItem}>
              <Icon
                name='login'
                color="#fff"
                type='simple-line-icon'
                style={styles.itemIcon}
              />
              <Text
                style={styles.itemText}>
                {this.props.t("login")}
              </Text>
            </View>
          </TouchableOpacity>)
        }
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 30,
    backgroundColor: '#999'
  },
  menuItem: {
    flexDirection: 'row',
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 25,
    borderColor: '#fff',
    borderWidth: 1,
    borderRadius: 3
  },
  itemText: {
    marginLeft: 16,
    fontSize: 18,
    color: '#fff'
  },
  itemIcon: {
    color: '#fff',
  },
  groupIconButton: {
    margin: 16,
    width: 80,
    height: 80,
    borderRadius: 40,
    shadowOffset: { width: 1, height: 2 },
    shadowColor: '#000',
    backgroundColor: "#e9e7e7",
    shadowOpacity: 0.3,
  },
  groupIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#fff',
  },
  userWrap: {
    flexDirection: 'row',
    borderColor: '#eee',
    borderBottomWidth: 1,
  },
  userWrapName: {
    flexDirection: 'column',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
  }
})
export default withNamespaces('common')(DrawerContainer)