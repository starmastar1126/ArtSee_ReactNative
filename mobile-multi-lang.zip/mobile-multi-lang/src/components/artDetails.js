import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView, Button, Alert } from 'react-native';
import {observer, inject} from "mobx-react/native"
import call from 'react-native-phone-call'
import Mailer from 'react-native-mail';
import { size } from 'lodash'
import {SITE_URL} from "../settings";
import AddHangup from "../images/AddHangup.png"
import Call from "../images/Call.png"
import Email from "../images/Email.png"
import FullWidthImage from "../common/FullWidthImage";
import Edit from "../images/Edit.png"
import {backButton} from "./ui";
import { withNamespaces } from 'react-i18next'

@inject('stateStore', 'artStore')
@observer
class ArtDetailsScreen extends Component {
  static navigationOptions = ({ navigation, screenProps: { t } }) => {
    return {
      title: t('art_details'),
      headerLeft: backButton(navigation),
      headerRight: (<TouchableOpacity
        onPress={navigation.state.params.addToHandup}
        style={{marginRight: 16}}
      >
        <Image source={AddHangup}/>
      </TouchableOpacity>)
    }
  }

  constructor() {
    super()
  }

  handleEdit = (item) => {
    this.props.navigation.navigate('ArtCreate', {item: item})
  }

  addToHandup = () => {
    const item = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.item || {};

    this.props.navigation.navigate('SelectWall', {art: item})
  }

  handleEmail = (email, artName, author) => {
    Mailer.mail({
      subject: `I'm interested in "${artName}" by ${author} I saw on ArtSee`,
      recipients: [email],
      body: this.props.t("mail_body"),
      isHTML: true,
      attachment: {
        path: '',  // The absolute path of the file from which to read data.
        type: '',   // Mime Type: jpg, png, doc, ppt, html, pdf, csv
        name: '',   // Optional: Custom filename for attachment
      }
    }, (error, event) => {
      Alert.alert(
        error,
        event,
        [
          {text: this.props.t("btn_ok"), onPress: () => console.log('OK: Email Error Response')},
          {text: this.props.t("btn_cancel"), onPress: () => console.log('CANCEL: Email Error Response')}
        ],
        { cancelable: true }
      )
    });
  }

  handleCall = (phoneNumber) => {
    const args = {
      number: phoneNumber, // String value with the number to call
      prompt: true // Optional boolean property. Determines if the user should be prompt prior to the call
    }

    Alert.alert(this.props.t("call_gal"), `Tap "Call" to dial ${phoneNumber}.`,
      [
        {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        {text: 'Call', onPress: () => call(args).catch((error) => console.log('error'))},
      ],
      { cancelable: true }
    )
  }

  handleReserve = (item) => {
    const { stateStore, artStore, navigation } = this.props

    if (stateStore.isAuthenticated && stateStore.user) {
      const { email, firstName, lastName, phone } = stateStore.user
      const { galleryEmail, qrCode, imageName } = item

      Alert.alert(this.propt.t("reserve_title"),
        `The following information will be sent to the gallery:\n\n${email}\n${firstName}\n${lastName}\n${phone}`,
        [
          {text: this.props.t("btn_cancel"), onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
          {text: this.props.t("btn_reserve"), onPress: () => artStore.reserve({contactEmail: galleryEmail, qr: qrCode, artName: imageName})},
        ],
        { cancelable: false }
      )
    } else {
      Alert.alert(this.propt.t("login_requred"), this.propt.t("login_requred_body"),
        [
          {text: this.props.t("btn_cancel"), onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
          {text: this.props.t("btn_login"), onPress: () => navigation.navigate('Login')},
        ],
        { cancelable: false }
      )
    }
  }

  componentWillMount() {
    this.props.navigation.setParams({ addToHandup: this.addToHandup });
  }

  render() {
    const item = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.item || {};

    return (
      <View style={styles.container}>
        <ScrollView scrollEnables={false} style={styles.container}>
          {item.imagePath
            ? <View style={styles.imageWrap}>
                <Image source={{uri: `file://${item.imagePath}`}} style={{height: 183, width: 'auto', resizeMode: 'contain'}}/>
              </View>
            : null
          }
          <View style={{marginHorizontal: 16}}>
            <Text
              style={[styles.textStyle, styles.imageTitle]}
            >
              {item.imageName && item.imageName.toUpperCase()}
            </Text>
            <Text style={[styles.textStyle, styles.artistName]}>by {item.artistName}</Text>
            <View style={{marginVertical: 21}}>
              {item.yearProduced ? <Text style={[styles.textStyle, styles.details]}>({item.yearProduced})</Text> : null}
              <Text style={[styles.textStyle, styles.details]}>
                {item.materials}
              </Text>
              {item.height || item.width ? <Text style={[styles.textStyle, styles.details]}>{+Number(item.width || 0).toFixed(2) || ''} x {+Number(item.height || 0).toFixed(2) || ''}</Text> : null}
            </View>
            <Text style={[styles.description]}>
                {item.imageDescription}
            </Text>
            <View style={{flexDirection: 'row'}}>
              <View style={{flexDirection: 'column', flex: 1}}>
                <Text style={styles.bottomTextStyle}>{item.galleryName}</Text>
                <Text style={styles.bottomTextStyle}>{item.galleryContactPerson}</Text>
                <Text style={styles.bottomTextStyle}>{item.galleryStreet1}</Text>
                <Text style={styles.bottomTextStyle}>{item.galleryStreet2}</Text>
                <Text style={styles.bottomTextStyle}>{item.galleryCity}</Text>
                <Text style={[styles.bottomTextStyle, styles.contact]}>{item.galleryEmail}</Text>
                <Text style={[styles.bottomTextStyle, styles.contact]}>{item.galleryPhone}</Text>
              </View>
              <View style={{flexDirection: 'column', flex: 1, alignItems: 'flex-end'}}>
                <Text style={styles.bottomTextStyle}>{item.expoName}</Text>
                <Text style={styles.bottomTextStyle}>{item.expoYear}</Text>
                <Text style={styles.bottomTextStyle}>{item.expoBooth}</Text>
              </View>
            </View>
          </View>
        </ScrollView>
        <View style={styles.bottomBar}>
          <View style={{width: '30%', paddingLeft: 16, flexDirection: 'row', alignItems: 'center'}}>
            {size(item.qrCode) > 0
              ? [item.galleryEmail ? <TouchableOpacity key="1" onPress={() => this.handleEmail(item.galleryEmail, item.imageName, item.artistName)} style={{marginRight: 8}}>
                <Image source={Email}/>
              </TouchableOpacity> : null,
                item.galleryPhone ? <TouchableOpacity key="2" onPress={() => this.handleCall(item.galleryPhone)}>
              <Image source={Call}/>
              </TouchableOpacity> : null]
              : null
            }
          </View>
          <View style={{width: '40%', justifyContent: 'center', alignItems: 'center'}}>
            {item.canReserve
              ? <Button
                onPress={() => this.handleReserve(item)}
                title={this.props.t("btn_reserve")}
                color="#000"
                buttonStyle={{marginHorizontal: 'auto'}}
              />
              : null
            }
          </View>
          <View style={{width: '30%', flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', paddingRight: 16}}>
            {size(item.qrCode) > 0
              ? null
              : <TouchableOpacity onPress={() => this.handleEdit(item)}>
                <Image source={Edit}/>
              </TouchableOpacity>
            }
          </View>
        </View>
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  imageWrap: {
    marginVertical: 18,
  },
  imageTitle: {
    fontFamily: 'Avenir-Book',
    color: '#343434',
    fontSize: 21,
    lineHeight: 24,
  },
  artistName: {
    fontFamily: 'Georgia',
    color: '#343434',
    fontSize: 16,
    lineHeight: 18,
  },
  details: {
    fontFamily: 'Georgia',
    fontSize: 14,
    lineHeight: 16,
    color: '#343434',
  },
  price: {
    fontFamily: 'Georgia',
    fontSize: 17,
    color: '#343434',
    marginBottom: 21,
  },
  description: {
    fontFamily: 'Avenir-Book',
    fontSize: 13,
    color: '#343434',
    lineHeight: 16,
    marginBottom: 29,
  },
  bottomBar: {
    height: 40,
    borderTopWidth: 1,
    borderTopColor: '#000',
    flexDirection: 'row'
  },
  textStyle: {
    textAlign: 'center',
  },
  bottomTextStyle: {
    fontFamily: 'Arial',
    fontSize: 11,
    color: '#000'
  },
  contact: {
    color: '#e53935'
  }
});

//make this component available to the app
export default withNamespaces('common')(ArtDetailsScreen)