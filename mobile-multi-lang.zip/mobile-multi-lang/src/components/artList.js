import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import {observer, inject} from "mobx-react/native"
import { forEach, find } from 'lodash'
import realm from '@store/realm';

import StarEmpty from "../images/StarEmpty.png"
import StarFilled from "../images/StarFilled.png"
import StandaloneAddSmall from "../images/StandaloneAddSmall2x.png"
import AddAll from "../images/AddAll.png"
import {backButton, closeButton} from "./ui";
import {SITE_URL} from "../settings";
import ActivityIndicatorElement from "../common/ActivityIndicatorElement";
import { withNamespaces } from 'react-i18next'

@inject('stateStore', 'artStore')
@observer
class ArtListScreen extends Component {
  static navigationOptions = ({ navigation, screenProps: { t } }) => {
    const { params } = navigation.state

    return {
      title: params && params.artistName || t("artlist"),
      headerLeft: backButton(navigation),
      headerRight: (<View style={{marginRight: 16, flexDirection: 'row'}}>
        <TouchableOpacity onPress={params.handleAddAll} style={{marginRight: 16}}>
          <Image source={AddAll}/>
        </TouchableOpacity>
        {closeButton(navigation)}
      </View>)
    }
  }
  constructor(props) {
    super(props)
  }

  state = {update: false}

  handleAddAll = () => {
    console.log('handleAddAll')
    // const notAdded = find(this.props.stateStore.artList.slice(), (art) => {
    //   return !art.isAdded
    // })
    //
    // console.log('notAdded', notAdded)
    // if (notAdded) {
    //   this.props.artStore.addArt(notAdded, () => {
    //     this.handleAddAll()
    //   })
    // } else {
    //   this.props.artStore.checkArtList()
    // }
    const arr = [...this.props.stateStore.artList.slice()]
    forEach(arr, (art) => {
      if (!art.isAdded) {
        this.props.artStore.addArt(art, () => {
          // this.props.artStore.checkArtList()
          this.setState({update: !this.state.update})
          console.log('done')
        })
      }
    })
  }

  handleAdd = (art) => {
    this.props.artStore.addArt(art, () => {
      // this.props.artStore.checkArtList()
      this.setState({update: !this.state.update})
      console.log('done')
    })
  }


  componentWillMount() {
    const params = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params
    const galleryID =  params && params.galleryID
    const firstName = params && params.firstName
    const lastName = params && params.lastName

    this.props.artStore.artList(galleryID, firstName, lastName);
  }

  componentDidMount() {
    this.props.navigation.setParams({handleAddAll: this.handleAddAll})
  }

  componentWillUnmount() {
  }

  renderArt = ({item, index}) => {
    const art = item || {}

    console.log('item', art, art.isAdded, index, art.serverImagePath)
    return (
      <View style={styles.itemContainer}>
        {index % 2 === 0 && art.serverImagePath
          ? <Image source={{uri: `${SITE_URL}${art.serverImagePath}`}} style={{height: 150, width: 150, resizeMode: 'cover'}}/>
          : null
        }
        <View style={{flexDirection: 'column', alignItems: 'center', flex: 1, paddingHorizontal: 8}}>
          <Text
            adjustsFontSizeToFit
            ellipsizeMode="tail"
            numberOfLines={2}
            style={[styles.textStyle, {fontSize: 20, textAlignVertical: 'bottom', lineHeight: 25, height: 55}]}
          >
            {art.imageName && art.imageName.toUpperCase()}
          </Text>

          {art.artistName
            ? <Text adjustsFontSizeToFit style={[styles.textStyle, {fontSize: 16, height: 30, marginBottom: 16}]}>by {art.artistName}</Text>
            : null
          }

          <Text
            adjustsFontSizeToFit
            ellipsizeMode="tail"
            numberOfLines={2}
            style={[styles.textStyle, {fontSize: 12, height: 15}]}
          >
            {art.materials}
          </Text>
          <Text
            adjustsFontSizeToFit
            ellipsizeMode="tail"
            numberOfLines={2}
            style={[styles.textStyle, {fontSize: 12, height: 15}]}
          >
            {art.height || art.width ? <Text style={[styles.textStyle, {fontSize: 12}]}>{Number(art.width || 0).toFixed(2) || ''} x {Number(art.height || 0).toFixed(2) || ''}</Text> : null}
          </Text>
        </View>
        {art.isAdded
          ? null
          : (<View style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginRight: 16}}>
            <TouchableOpacity onPress={() => this.handleAdd(art)}>
              <Image source={StandaloneAddSmall}/>
            </TouchableOpacity>
          </View>)
        }
        {index % 2 !== 0 && art.serverImagePath
          ? <Image source={{uri: `${SITE_URL}${art.serverImagePath}`}} style={{height: 150, width: 150, resizeMode: 'cover'}}/>
          : null
        }
      </View>
    )
  }

  render() {
    const artList = this.props.stateStore.artList.slice()
    console.log('artList', artList)

    return (
      <View
        style={styles.container}
        onLayout={(event) => this.setState({
          width : event.nativeEvent.layout.width,
          height : event.nativeEvent.layout.height
        })}
      >
        <FlatList
          keyExtractor={(item) => `${item.qrCode}`}
          data={artList}
          renderItem={this.renderArt}
        />
        <ActivityIndicatorElement width={this.state.width} height={this.state.height} />
      </View>
    );
  }
}

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: 'row',
    height: 151,
    borderBottomWidth: 1,
    borderBottomColor: "#000"
  },
  textStyle: {
    textAlign: 'center',
    color: '#000'
  }
});

//make this component available to the app
export default withNamespaces('common')(ArtListScreen)