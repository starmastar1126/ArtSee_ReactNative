import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, Animated } from 'react-native';
import { size } from 'lodash'
import Draggable from "../common/Draggable";
import DeleteButton from '../images/DeleteButton.png'
import {Icon} from "react-native-elements";

class DragArtItem extends Component {
  render() {
    const { show, onDrag, active, rotate = 0, imagePath, width, height, onRotateBack, onRotateForward, onDelete, offsetX, offsetY, onFocus, onBlur } = this.props

    console.log('width, height', imagePath, width, height, offsetX, offsetY)
    return active
      ? (<Draggable pressDragRelease={onDrag} reverse={false} offsetX={offsetX} offsetY={offsetY} >
        <View style={[styles.artContainer, show ? styles.wrapper : {}]}>
          {imagePath
            ? (<View style={{transform: [{rotateZ: `${rotate}deg`},]}}>
              <Animated.Image
              source={{uri: `file://${imagePath}`}}
              style={{height: height || 100, width: width || 100, resizeMode: 'contain'}}
              /></View>)
            : null
          }
          {show
            ? <View style={styles.rotate}>
              <Icon
                name={'reply'}
                type='entypo'
                color={'#eee'}
                iconStyle={{paddingRight: 8}}
                onPress={onRotateBack}
              />
              <Icon
                name={'forward'}
                type='entypo'
                color={'#eee'}
                iconStyle={{paddingLeft: 0}}
                onPress={onRotateForward}
              />
            </View>
            : null
          }
          {show
            ? <View style={{position: 'absolute', top: 5, left: 5}}>
              <TouchableOpacity onPress={onDelete}>
                <Image source={DeleteButton}/>
              </TouchableOpacity>
            </View>
            : null
          }
        </View>
      </Draggable>)
      : imagePath
        ? (<Draggable pressDragRelease={onDrag} pressInDrag={onFocus} reverse={false} offsetX={offsetX} offsetY={offsetY}>
          <View style={{transform: [{rotateZ: `${rotate}deg`},], elevation: 3, margin: 26}}>
            <Animated.Image
              source={{uri: `file://${imagePath}`}}
              style={{height: height || 100, width: width || 100, resizeMode: 'contain'}}
            />
          </View>
        </Draggable>)
        : null
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  artContainer: {
    alignSelf: 'flex-start',
    borderWidth: 5,
    borderColor: 'transparent',
    borderRadius: 8,
    padding: 16,
    margin: 5
  },
  wrapper: {
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderColor: '#eee',
    elevation: 2,
  },
  rotate: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 16
  }
});

export default DragArtItem;
