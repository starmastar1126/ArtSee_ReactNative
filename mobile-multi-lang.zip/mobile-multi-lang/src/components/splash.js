import React, { Component } from 'react';
import {View, StyleSheet, ImageBackground, Image, Text} from 'react-native';
import logo from '../images/logo.png'

class SplashScreen extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.logoWrap}>
          <Image source={logo} />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center'
  }
});

export default SplashScreen;
