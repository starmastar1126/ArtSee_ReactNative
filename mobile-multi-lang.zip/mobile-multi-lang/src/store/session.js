import axios from 'axios'
import { observable, runInAction, action, autorun, computed, reaction, ObservableMap } from 'mobx';
import stateStore from './state'
import {API_URL} from "../settings";


class SessionStore {
  constructor () {
    console.disableYellowBox = true;

    axios.defaults.baseURL = API_URL;
    // axios.defaults.headers.common['Authorization'] = AUTH_TOKEN;
    axios.defaults.headers.post['Content-Type'] = 'application/json';

    stateStore.isInit = true
  }

  @action handleConnectionChange = (isConnected) => {
    console.log('NetInfo status', isConnected)

    stateStore.isConnected = isConnected
  };

  @action handleAppStateChange = (nextAppState) => {
    // if (this.appState && this.appState.match(/inactive|background/) && nextAppState === 'active') {
    if (nextAppState === 'active') {
      console.log('App has come to the foreground!')
      if (stateStore.isAuthenticated) {
        stateStore.isForeground = true
      }
    } else if (nextAppState === 'background') {
      if (stateStore.isAuthenticated) {
        stateStore.isForeground = false
      }
    }

    stateStore.appState = nextAppState;
  }

  @action logout = async () => {
    console.log('Logout')
    await this.clearStore()
  }

  @action clearStore = () => {
    this.isAuthenticated = false
    this.user = null
    navigator.geolocation.clearWatch(this.watchId);
  }
}

export default new SessionStore();