import { AsyncStorage } from 'react-native'
import { observable, runInAction, action, autorun, computed, reaction, ObservableMap } from 'mobx';
import { findIndex } from 'lodash'

class StateStore {
  @observable isInit = false; // Is initialized
  @observable isLoading = false; // Activity indicator status
  @observable isAuthenticated = false; // Is User authenticated
  @observable user = null // User data {name: username, tokens: 0}
  @observable password = null // User data {name: username, tokens: 0}
  @observable displayName = '' // User displayName
  @observable photo_url = null // Users photo_url
  @observable isConnected = false // Internet connection
  @observable isForeground = false // Is app foreground
  @observable arts = [] // Groups list
  @observable galleryDirectory = [] // Gallery Directory
  @observable artistList = [] // Artist List
  @observable artList = [] // Artist List
  longitude = null // Longitude
  latitude = null // Latitude


  constructor () {
    autorun(() => {console.log('isAuthenticated', this.isAuthenticated)})
    autorun(() => {console.log('isInit', this.isInit)})
    autorun(() => {console.log('isConnected', this.isConnected)})
    autorun(() => {console.log('isForeground', this.isForeground)})
    autorun(() => {console.log('user', this.user)})
    autorun(() => {console.log('longitude', this.longitude)})
    autorun(() => {console.log('latitude', this.latitude)})
    autorun(() => {console.log('photo_url', this.photo_url)})
    autorun(() => {console.log('artList', this.artList.slice())})
  }

  @action clearStore = () => {
    this.isAuthenticated = false
    this.user = null
  }

  @action replacePost = (post) => {
    let postIndex = findIndex(this.posts, (item) => {
      return item._id === post._id
    })

    if (postIndex !== -1) {
      this.posts[postIndex] = { ...post }
    }
  }

  @action getPrivateGroupPassword = (groupId) => {
    let group = find(this.privateGroups, (item) => {
      return item.id === groupId
    })

    return group ? group.password : ''
  }

  @action checkPrivateGroup = (groupId) => {
    let groupIndex = findIndex(this.privateGroups, (item) => {
      return item.id === groupId
    })

    return groupIndex !== -1
  }

  @action addPrivateGroups = (groupId, password) => {
    console.log('addPrivateGroups', groupId, password)
    let groupIndex = findIndex(this.privateGroups, (item) => {
      return item.id === groupId
    })

    if (groupIndex === -1) {
      this.privateGroups.push({ id: groupId, password })

      console.log('store privateGroups', { id: groupId, password })
      AsyncStorage.setItem('privateGroups', JSON.stringify(this.privateGroups))
        .then(json => console.log('success!', json))
        .catch(error => console.log('error!', error));
    }
  }
}

export default new StateStore();