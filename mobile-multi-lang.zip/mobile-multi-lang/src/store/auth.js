import {action, runInAction, autorun} from 'mobx'
import axios from 'axios'
import { Alert } from 'react-native';
import stateStore from '@store/state'
import uiStore from '@store/ui'
import {DEFAULT_PASSWORD} from "../settings";
// import RNFetchBlob from 'react-native-fetch-blob'
// import firebase from 'react-native-firebase';

class AuthStore {
  constructor () {
    console.ignoredYellowBox = [
      'Setting a timer'
    ];

    // this.checkAuth()
    autorun(() => {
        if (stateStore.isConnected) {
            if (!stateStore.isInit) {
                // this.checkAuth()
            }
        }
    })

    autorun(() => {
      if (stateStore.isAuthenticated && stateStore.user && stateStore.user.uid) {
        console.log('stateStore.user.uid', stateStore.user.uid, {...stateStore.user})
      }
    })
  }

  /**
   * Store User data from db
   *
   */
  @action setUserFromBase = (uid, cb) => {
    if (stateStore.isConnected) {
      // firebase.firestore().collection('users').doc(uid).get()
      //   .then((snapshot) => {
      //     this.setUser(snapshot.data(), cb)
      //   })
      //   .catch((err) => {
      //     console.log('err', err)
      //   })
    } else {
      uiStore.noConnect()
    }
  }

  /**
   * Store User data
   *
   */
  @action setUser = (user = {}, cb) => {
    // stateStore.user = user
    // stateStore.displayName = user && user.displayName || ''
    console.log('setUser', user)
    stateStore.user = user
    stateStore.displayName = user && user.displayName || ''
    stateStore.tokens = user && user.tokens || 0
    stateStore.photo_url = user && user.photo_url || null

    if (cb && typeof cb === 'function') {
      cb()
    }
  }


  /**
   * Check if User is athenticated
   */
  @action checkAuth = () => {
    console.log('checkAuth')
    const self = this
    // this.authSubscription = firebase.auth().onAuthStateChanged((user) => {
    //   if (user) {
    //     console.log('onAuthStateChanged', user)
    //     this.setUserFromBase(user.uid, () => {
    //       stateStore.isAuthenticated = true
    //       stateStore.isInit = true
    //     })
    //     User is signed in.
      // } else {
      //   stateStore.isAuthenticated = false
      //   stateStore.isInit = true
      // }
      //
      // self.authSubscription()
    // });
  }

  /**
   * Reset Password
   * @param email
   */
  @action resetPassword = async (email, cb) => {
    console.log('resetPassword', email)

    if (stateStore.isConnected) {
      try {
        stateStore.isLoading = true
        const response = await axios.post(`/reset`, {email});
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          Alert.alert("Connection Error",
            'There was a connection error while trying to connect. Please verify you have internet access and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: Reset Error Response')}
            ],
            {cancelable: true}
          )
        }
      }
    } else {
      uiStore.noConnect()
    }
  }

  /**
   * Sign Up user
   * @param data, photo
   */
  @action register = async (data, cb) => {
    console.log('register', data)

    if (stateStore.isConnected) {
      try {
        stateStore.isLoading = true
        const response = await axios.post(`/users`, data);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (response.data) {
            stateStore.user = response.data
            stateStore.password = data.password
            stateStore.isAuthenticated = true
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          Alert.alert("Connection Error",
            'There was a connection error while trying to connect. Please verify you have internet access and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: SignUp Error Response')}
            ],
            {cancelable: true}
          )
        }
      }
    } else {
      uiStore.noConnect()
    }
  }

  /**
   * Login/Register by Facebook
   * @param data, photo
   */
  @action loginFacebook = async (facebookId, profile = {}, cb) => {
    console.log('register', facebookId, profile)

    if (stateStore.isConnected && facebookId) {
      try {
        stateStore.isLoading = true
        const data = {
          facebookID: facebookId,
          email: profile.email || '',
          firstName: profile.first_name || 'First',
          lastName: profile.last_name || 'Last',
          phone: profile.phone || '',
          password: DEFAULT_PASSWORD,
        }
        const response = await axios.post(`/users`, data);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (response.data) {
            stateStore.user = response.data
            stateStore.password = DEFAULT_PASSWORD
            stateStore.isAuthenticated = true
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          console.log('error', error.response)
          Alert.alert("Connection Error",
            'There was a connection error while trying to connect. Please verify you have internet access and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: SignIn Error Response')}
            ],
            {cancelable: true}
          )
        }
        if (cb && typeof cb === 'function') {
          cb(false)
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      } else {
        uiStore.showError("Facebook ID not found")
      }
      if (cb && typeof cb === 'function') {
        cb(false)
      }
    }
  }

  /**
   * Login
   * @param username
   * @param password
   * @param cb
   * @returns {Promise.<void>}
   */
  @action login = async (email, password, cb) => {
    console.log('login', stateStore.isConnected, email, password)
    if (stateStore.isConnected && email && password) {
      try {
        stateStore.isLoading = true
        const response = await axios.get(`/users?email=${email}&password=${password}`);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (response.data) {
            stateStore.user = response.data
            stateStore.password = password
            stateStore.isAuthenticated = true
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          Alert.alert('Login Error',
            'A user matching the provided login name and password was not found. Please check them and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: Email Error Response')}
            ],
            {cancelable: true}
          )
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

  /**
   * Update user data
   * @param data
   * @param cb
   * @returns {Promise.<void>}
   */
  @action update = async (data, cb) => {
    console.log('login', stateStore.isConnected, data)
    const email = stateStore.user && stateStore.user.email
    const password = stateStore.password

    if (stateStore.isConnected && email && password) {
      try {
        stateStore.isLoading = true

        const response = await axios.patch(`/users`, {...data, email, password});
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          stateStore.user = {...stateStore.user, ...data, email: data.newEmail}
          stateStore.isAuthenticated = true

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        this.logout()
        if (error.response) {
          stateStore.responseErrors = error.response
          Alert.alert('Login Error',
            'A user matching the provided login name and password was not found. Please check them and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: Email Error Response')}
            ],
            {cancelable: true}
          )
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

  /**
   * Change Password
   * @param data
   * @param cb
   * @returns {Promise.<void>}
   */
  @action changePassword = async (newPassword, cb) => {
    console.log('login', stateStore.isConnected, newPassword)
    const email = stateStore.user && stateStore.user.email
    const password = stateStore.password

    if (stateStore.isConnected && email && password && newPassword) {
      try {
        stateStore.isLoading = true

        const response = await axios.patch(`/users`, {newPassword, email, password});
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          stateStore.password = newPassword

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        this.logout()
        if (error.response) {
          stateStore.responseErrors = error.response
          Alert.alert('Login Error',
            'A user matching the provided login name and password was not found. Please check them and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: Email Error Response')}
            ],
            {cancelable: true}
          )
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

  /**
   * Save Settings
   */
  @action settings = async (data, cb) => {
    const payload = {settings: data, username: stateStore.user.uid}
    const uid = stateStore.user && stateStore.user.uid || null
    console.log('settings', payload)

    if (stateStore.isConnected && uid) {
      let updates = {}

      updates['/users/' + uid + '/settings'] = data
      // firebase.database().ref().update(updates)
      // firebase.firestore().collection('users').doc(uid).update({settings: data})
      //   .then(() => {
      //     stateStore.isLoading = false
      //     console.log('user settings updated')
      //     stateStore.user.settings = data
      //   })
      //   .catch((err) => {
      //     stateStore.isLoading = false
      //     console.log('Error user settings update', err)
      //   })
    } else {
      uiStore.noConnect()
    }
  }

  /**
   * Logout
   */
  @action logout = (cb) => {
    stateStore.isAuthenticated = false
    stateStore.user = null
    stateStore.password = null
    // firebase.auth().signOut()
    //   .then(() => {
    //     stateStore.isLoading = false
    //     this.setUser()
    //   }, function(error) {
    //     stateStore.isLoading = false
    //     console.log(error)
    //     uiStore.showError(error && error.message)
    //   });

  }
}

export default new AuthStore();
