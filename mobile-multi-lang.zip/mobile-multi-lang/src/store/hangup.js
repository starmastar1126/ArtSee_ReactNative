import {action, runInAction, autorun} from 'mobx'
import { AsyncStorage, Platform, ImageEditor, Image, PixelRatio } from "react-native";
import axios from 'axios'
import { findIndex, find, forEach, filter, map } from 'lodash'
import RNFetchBlob from 'react-native-fetch-blob'
import UUIDGenerator from 'react-native-uuid-generator';
import stateStore from '@store/state'
import uiStore from '@store/ui'
import realm from '@store/realm';
import { captureRef } from "react-native-view-shot"
import ImageResizer from 'react-native-image-resizer';
import {API_URL, SITE_URL} from "../settings";

// const hangups = [
//   {
//     height: 103.51,
//     width: 138.01,
//     wallName: "Den",
//     wallDescription: "A sample room.",
//     pixelHeight: 1152,
//     pixelWidth: 1536,
//     image: Room3,
//   },
//   {
//     height: 113.28,
//     width: 151.05,
//     wallName: "Living Room 1",
//     wallDescription: "A sample room.",
//     pixelHeight: 1152,
//     pixelWidth: 1536,
//     image: Room1,
//   },
//   {
//     height: 168.18,
//     width: 221.36,
//     wallName: "Living Room 2",
//     wallDescription: "A sample room.",
//     pixelHeight: 1152,
//     pixelWidth: 1536,
//     image: Room2,
//   },
//   {
//     height: 108.8,
//     width: 105.25,
//     wallName: "Hearth Room",
//     wallDescription: "A sample room.",
//     pixelHeight: 1152,
//     pixelWidth: 1536,
//     image: Room4,
//   }
// ]

class HangupStore {
  constructor () {
    // Create directory for Hangup pictures
    RNFetchBlob.fs.mkdir(`${RNFetchBlob.fs.dirs.DocumentDir}/Hangups/`)
      .then(() => {  })
      .catch((err) => {  })

    autorun(() => {
      if (stateStore.isConnected) {
        console.log('hangup load')
        AsyncStorage.getItem('hangupLoaded')
          .then(json => {
            console.log('hangupLoaded get', json);
            stateStore.hangupLoaded = json === 'true'

            if (json !== 'true') {
              console.log('LOAD HANGUPS')
              // this.load()
            }
          })
          .catch(error => {console.log('hangupLoaded error', error); stateStore.hangupLoaded = false });
      }
    })
  }

  /**
   * Create Hangup
   */
  @action create = (data, cb) => {
    UUIDGenerator.getRandomUUID((uuid) => {
      console.log('hangup uuid', uuid, data)

      UUIDGenerator.getRandomUUID((artUuid) => {
        console.log('hangup uuid', uuid, artUuid, data)

        const record = {
          id: uuid,
          width: parseFloat(data.wall.width),
          height: parseFloat(data.wall.height),
          pixelWidth: data.wall.pixelWidth,
          pixelHeight: data.wall.pixelHeight,
          wall: {
            // ...data.wall
            id: data.wall.id,
            wallName: data.wall.wallName,
            imagePath: data.wall.imagePath,
            width: data.wall.width,
            height: data.wall.height,
            pixelWidth: data.wall.pixelWidth,
            pixelHeight: data.wall.pixelHeight,
          },
          arts: [{
            // ...data.art,
            id: artUuid,
            artId: data.art.id,
            x: - data.art.width / 2,
            y: - data.art.height / 2,
            pixelWidth: data.art.pixelWidth,
            pixelHeight: data.art.pixelHeight,

            imageName: data.art.imageName,
            imagePath: data.art.imagePath,
            artistName: data.art.artistName,
            width: data.art.width,
            height: data.art.height,
            rotation: data.art.rotation,
          }]
        }

        console.log('hangup create', record)
        try {
          realm.write(() => {
            const hangup = realm.create('hangups', record, true);

            if (cb && typeof cb === 'function') {
              cb({...hangup})
            }
          });
        } catch (error) {
          console.log('realm create hangup', error)
          if (cb && typeof cb === 'function') {
            cb(false)
          }
        }
      })
    })
  }

  /**
   * Update Hangup
   */
  @action update = (id, data, cb) => {
    console.log('update hangup', id, data)

    UUIDGenerator.getRandomUUID((artId) => {
      console.log('hangup uuid', id, artId, data)

      try {
        realm.write(() => {
          const hangup = realm.objectForPrimaryKey('hangups', id)

          console.log('hangup 1', hangup)
          console.log('data.art', {...data.art, id: artId, artId: data.art.id, x: - data.art.width / 2, y: - data.art.height / 2})

          if (hangup && data.art) {
            // const arts = hangup.arts.slice() || []
            // arts.push({...data.art})
            hangup.arts.push({...data.art, id: artId, artId: data.art.id, x: - data.art.width / 2, y: - data.art.height / 2})
          }

          console.log('hangup 2', hangup)
          if (cb && typeof cb === 'function') {
            cb(true)
          }
        });
      } catch (error) {
        console.log('realm create hangup', error)
        if (cb && typeof cb === 'function') {
          cb(false)
        }
      }
    })
  }

  /**
   * Delete Art from Hangup
   */
  @action deleteArt = (id, artId, cb) => {
    console.log('update hangup', id, artId)

    try {
      realm.write(() => {
        const hangup = realm.objectForPrimaryKey('hangups', id)

        console.log('hangup 1', hangup)

        if (hangup && artId) {
          const arts = filter(hangup.arts.slice(), (a) => a.id !== artId) || []

          hangup.arts = arts
        }

        console.log('hangup 2', hangup)
        if (cb && typeof cb === 'function') {
          cb(true)
        }
      });
    } catch (error) {
      console.log('realm delete hangup', error)
      if (cb && typeof cb === 'function') {
        cb(false)
      }
    }
  }

  /**
   * Load default hangups from DB
   * @param tab
   * @param query
   * @param cb
   * @returns {Promise.<void>}
   */
  @action load = async (cb) => {
    console.log('wall list')

    forEach(hangups, (data, index) => {
      UUIDGenerator.getRandomUUID((uuid) => {
        console.log('image', data.image, uuid)

        const record = {
          ...data,
          id: uuid,
          width: parseFloat(data.width),
          height: parseFloat(data.height),
          pixelWidth: 0,
          pixelHeight: 0,
          imagePath: `${data.image}`,
          // imageName: photo.fileName || '',
        }

        try {
          realm.write(() => {
            const art = realm.create('hangups', record, true);
          });
        } catch (error) {
          console.log('realm create art error', error)
        }
      })
    })

    AsyncStorage.setItem('hangupLoaded', 'true')
      .then(res => {
        console.log('hangupLoaded set', true);
        stateStore.hangupLoaded = true;
      })
      .catch(error => {
        console.log('hangupLoaded error', error);
        stateStore.hangupLoaded = false
      });

    if (cb && typeof cb === 'function') {
      cb(true)
    }
  }

  @action rotate = (id, artId, value, cb) => {
    console.log('rotate', id, value)
    try {
      realm.write(() => {
        const hangup = realm.objectForPrimaryKey('hangups', id);

        console.log('hangup', hangup)
        if (hangup) {
          const art = find(hangup.arts, (a) => a.id === artId)
          const arts = filter(hangup.arts, (a) => a.id !== artId)

          if (art) {
            let rotation = art.rotation + value

            if (rotation >= 360) {
              rotation = 0
            }

            if (rotation < 0) {
              rotation = 360 + rotation
            }

            console.log('new rotation', art.rotation, value, rotation)
            art.rotation = rotation

            hangup.arts = [...arts, art]

            if (cb && typeof cb === 'function') {
              cb(true)
            }
          }
        }
      });
    } catch (error) {
      console.log('realm toggle Favorit hangup', error)
    }
  }

  @action setXY = (id, artId, x, y, container, ref, cb) => {
    console.log('setXY', id, artId, x, y, container)
    this.snapshot(ref, id, container, cb).then((res) => {
      console.log('final', res)

      try {
        realm.write(() => {
          const hangup = realm.objectForPrimaryKey('hangups', id);

          console.log('hangup', hangup)
          if (hangup) {
            const art = find(hangup.arts, (a) => a.id === artId)
            const arts = filter(hangup.arts, (a) => a.id !== artId)

            if (art && x !== null && y !== null) {

              if (art && x !== null && y !== null) {
                art.x = x
                art.y = y
              }

              hangup.arts = [...arts, art]
              hangup.imagePath = res

              // if (cb && typeof cb === 'function') {
              //   cb(true)
              // }
            }
          }
        });
      } catch (error) {
        console.log('realm toggle Favorit hangup', error)
      }
    })
  }

  @action saveHangup = (file, filename) => {
    return new Promise((resolve, reject) => {
      let source = file.replace('file://', '')

      const outputPath = `${RNFetchBlob.fs.dirs.DocumentDir}/`;

      // The imageStore path here is "rct-image-store://0"
      console.log('outputPath', source, outputPath)
      ImageResizer.createResizedImage(
          source,
          1280,
          1280,
          'JPEG',
          80,
          0,
          outputPath,
      ).then((success) => {
          console.log('ImageResizer', success);
          console.log('ImageResizer', success.path);
          source = success.path
          
          RNFetchBlob.fs.exists(source)
            .then((exist) => {
              console.log(`file ${exist ? '' : 'not'} exists`, source)

              if (exist) {
                const target = `${RNFetchBlob.fs.dirs.DocumentDir}/Hangups/${filename}`

                console.log('path source', source)
                console.log('path target', target)

                RNFetchBlob.fs.cp(source, target)
                  .then(() => {
                    console.log('img moved')
                    // Alert.alert(`img moved`, `${path} to ${target}`)
                    resolve(`file://${target}`)
                  })
                  .catch((err) => {
                    console.log('img move error', err)
                    reject(err)
                  })
              } else {
                reject()
              }

            })
            .catch((err) => {
              console.log('isExist', file, err)
              reject(err)
            })
          //If you console success.path then it will give you something like this
          // /var/mobile/Containers/Data/Application/3BA7E152-E21E-4ADD-84A3-8CCCBC7FBFAE
          // /Documents/var/mobile/Containers/Data/Application/3BA7E152-E21E-4ADD-84A3-8CCCBC7FBFAE/Documents/194D4C64-8EA9-4058-9307-BA1316347DA0.jpg
      }).catch((err) => {
          console.log('ImageResizer error', err)
          // reject(err)
      })
      }
    )
  }

  cropOptions = {
    format: "jpg",
    quality: 0.8,
    result: "tmpfile",
    snapshotContentContainer: false
  }

  @action snapshot = (ref, id, container, cb) =>
    (ref
        ? captureRef(ref, this.cropOptions)
        : null
    )
      .then((res) => {
          console.log('after capture')
          if (cb && typeof cb === 'function') {
            cb('123')
          }
          return this.cropOptions.result !== "tmpfile"
            ? res
            : new Promise((success, failure) =>
              // just a test to ensure res can be used in Image.getSize
              Image.getSize(
                res,
                (width, height) => (
                  console.log('getSize', res, width, height), success({res, width, height})
                ),
                failure
              )
            )
        }
      )
      .then(data => {
        console.log('after resize')
        // return this.saveHangup(data.res, `${id}.jpg`)
        // return data.res
        previewSource = {
          uri:
            this.cropOptions.result === "base64"
              ? "data:image/" + this.cropOptions.format + ";base64," + data.res
              : data.res
        }
        console.log('res', data, previewSource)
        const cropData = {
          offset: {
            x: PixelRatio.getPixelSizeForLayoutSize(container.x),
            y: PixelRatio.getPixelSizeForLayoutSize(container.y)
          },
          size: {
            width: (
              PixelRatio.getPixelSizeForLayoutSize(container.width)
            ),
            height: (
              PixelRatio.getPixelSizeForLayoutSize(container.height)
            )
          },
        };

        return new Promise((resolve, reject) => {
          ImageEditor.cropImage(
            previewSource.uri,
            cropData,
            (croppedUri) => {

              console.log('croppedUri', JSON.stringify(croppedUri))
              resolve(this.saveHangup(croppedUri, `${id}.jpg`))
              // resolve(croppedUri)
              // this.resize(
              //
              //   croppedUri,
              //   (cropData.size.width),
              //   (cropData.size.height)
              // ).then((resizedUri) =>
              //   resolve(resizedUri)
              // );
            },
            (failure) => reject(failure)
          );
        });
      })
      // .then(res =>
      //   ({previewSource: {
      //       uri:
      //         this.cropOptions.result === "base64"
      //           ? "data:image/" + this.cropOptions.format + ";base64," + res
      //           : res
      //     }
      //   })
      // )
      .catch(
        error => (
          console.log(error)
            // this.setState({ error, res: null, previewSource: null })
        )
      );

  @action delete = (id) => {
    try {
      realm.write(() => {
        const item = realm.objectForPrimaryKey('hangups', id);

        if (item) {
          realm.delete(item);
        }
      });
    } catch (error) {
      console.log('realm delete hangup error', error)
    }
  }

  @action toggleFavorit = (id) => {
    try {
      realm.write(() => {
        const item = realm.objectForPrimaryKey('hangups', id);

        if (item) {
          item.isFavorite = !item.isFavorite
        }
      });
    } catch (error) {
      console.log('realm toggle Favorit hangup', error)
    }
  }
}

export default new HangupStore();