import stateStore from './state';
import authStore from './auth';
import sessionStore from './session';
import artStore from './art';
import wallStore from './wall';
import hangupStore from './hangup';
import fsStore from './fs';
import uiStore from './ui';

export default {
  authStore,
  stateStore,
  sessionStore,
  artStore,
  wallStore,
  hangupStore,
  fsStore,
  uiStore,
};
