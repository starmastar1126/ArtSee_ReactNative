import {action, runInAction, autorun} from 'mobx'
import { AsyncStorage, Platform, Alert, Image } from "react-native";
import axios from 'axios'
import { replace, findIndex, find, forEach, map, size } from 'lodash'
import RNFetchBlob from 'react-native-fetch-blob'
import UUIDGenerator from 'react-native-uuid-generator';
import stateStore from '@store/state'
import uiStore from '@store/ui'
import realm from '@store/realm';
import {API_URL, SITE_URL} from "../settings";

class ArtStore {
  constructor () {
    // Create directory for Art pictures
    RNFetchBlob.fs.mkdir(`${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/`)
      .then(() => {  })
      .catch((err) => {  })

    RNFetchBlob.fs.ls(`${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/`)
    // files will an array contains filenames
      .then((files) => {
        console.log('Pictures files', files)
      })

    autorun(() => {
      if (stateStore.isConnected) {
        console.log('art load')
        AsyncStorage.getItem('artLoaded')
          .then(json => {
            console.log('artLoaded get', json);
            stateStore.artLoaded = json === 'true'

            if (json !== 'true') {
              console.log('LOAD ARTS')
              this.load()
            }
          })
          .catch(error => {console.log('artLoaded error', error); stateStore.artLoaded = false });
      }
    })
  }

  /**
   * Create Art
   */
  @action create = (data, photo, cb) => {
    // const payload = {...data, username: stateStore.user.username}
    UUIDGenerator.getRandomUUID((uuid) => {
      console.log('photo', uuid, data, photo)

      const PATH_TO_WRITE = Platform.OS === 'ios'
        ? (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
        : (photo && photo.fileName
          ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.fileName}`
          : (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
        )

      const record = {
        ...data,
        id: uuid,
        width: parseFloat(data.width),
        height: parseFloat(data.height),
        pixelWidth: photo.width,
        pixelHeight: photo.height,
        yearProduced: parseInt(data.yearProduced || 0),
        price: parseFloat(data.price || 0),
        imagePath: PATH_TO_WRITE,
        canReserve: !!(size(data.qrCode) && size(data.galleryEmail)),
        // imageName: photo.fileName || '',
      }

      console.log('art create', record)
      try {
        realm.write(() => {
          realm.create('arts', record, true);
          // fsStore.scanFile(record.imagePath)
          let PATH_FROM = ''

          if (Platform.OS === 'ios') {
            if (photo.uri) {
              PATH_FROM = photo.uri.replace('file://', '')
            }
          } else {
            if (photo.path && photo.fileName) {
              PATH_FROM = photo.path
            } else if (photo.uri) {
              PATH_FROM = photo.uri
            }
          }

          console.log('PATH_FROM', PATH_FROM)
          console.log('PATH_TO_WRITE', PATH_TO_WRITE)

          if (PATH_FROM) {
            RNFetchBlob.fs.cp(PATH_FROM, PATH_TO_WRITE)
              .then((res) => {
                console.log('move file res', res);
              })
              .catch((error) => {
                console.log('move file error', error)
              })
          }
        });
      } catch (error) {
        console.log('realm create art', error)
      }
    })
  }

  /**
   * Update Art
   */
  @action update = (data, photo, cb) => {

    console.log('update', data, photo)

    const record = {
        ...data,
        width: Number(data.width),
        height: Number(data.height),
        yearProduced: parseInt(data.yearProduced || 0),
        price: parseFloat(data.price || 0),
    }
    let PATH_TO_WRITE = ''
/* conflict master
  @action update = (data, cb) => {
      const photo = data.photoSource
      const PATH_TO_WRITE = Platform.OS === 'ios'
          ? (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
          : (photo && photo.fileName
                  ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.fileName}`
                  : (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
          )

      const record = {
          ...data,
          imagePath: PATH_TO_WRITE,
          width: Number(data.width),
          height: Number(data.height),
          yearProduced: parseInt(data.yearProduced || 0),
          price: parseFloat(data.price || 0),
      }

      console.log('art update', record)
      try {
          realm.write(() => {
              realm.create('arts', record, true);
              // fsStore.scanFile(record.imagePath)
          });

          let PATH_FROM = ''

          if (Platform.OS === 'ios') {
              if (data.photoSource && data.photoSource.uri) {
                  PATH_FROM = data.photoSource.uri.replace('file://', '')
              }
          } else {
              PATH_FROM = photo.uri
          }

          console.log('PATH_FROM', PATH_FROM)
          console.log('PATH_TO_WRITE', PATH_TO_WRITE)

          if (PATH_FROM) {
              RNFetchBlob.fs.cp(replace(PATH_FROM, 'file://', ''), PATH_TO_WRITE)
                  .then((res) => {
                      console.log('move file res', res);
                  })
                  .catch((error) => {
                      console.log('move file error', error)
                  })
          }
      } catch (error) {
          console.log('realm update art', error)
      }
*/
    if (photo) {
      PATH_TO_WRITE = Platform.OS === 'ios'
        ? (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
        : (photo && photo.fileName
            ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.fileName}`
            : (photo && photo.uri ? `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${photo.uri.substring(photo.uri.lastIndexOf('/') + 1, photo.uri.length)}` : '')
        )

      record.imagePath = PATH_TO_WRITE
    }

    console.log('art update', record)
    try {
        realm.write(() => {
          realm.create('arts', record, true);
          // fsStore.scanFile(record.imagePath)

          if (photo) {
            let PATH_FROM = ''

            if (Platform.OS === 'ios') {
              if (photo.uri) {
                PATH_FROM = photo.uri.replace('file://', '')
              }
            } else {
              if (photo.path && photo.fileName) {
                PATH_FROM = photo.path
              } else if (photo.uri) {
                PATH_FROM = photo.uri
              }
            }

            console.log('PATH_FROM', PATH_FROM)
            console.log('PATH_TO_WRITE', PATH_TO_WRITE)

            if (PATH_FROM) {
              RNFetchBlob.fs.cp(PATH_FROM, PATH_TO_WRITE)
                .then((res) => {
                  console.log('move file res', res);
                })
                .catch((error) => {
                  console.log('move file error', error)
                })
            }
          }
        });
    } catch (error) {
        console.log('realm update art', error)
    }

    if (cb && typeof cb === 'function') {
        cb(true)
    }
  }


  @action addArt = (data, cb) => {
    UUIDGenerator.getRandomUUID((uuid) => {
      console.log('addArt', uuid, data)

      const record = {
        ...data,
        id: uuid,
        width: parseFloat(data.width),
        height: parseFloat(data.height),
        pixelWidth: 0,
        pixelHeight: 0,
        yearProduced: parseInt(data.yearProduced),
        price: parseFloat(data.price),
        canReserve: !!(size(data.qrCode) && size(data.galleryEmail)),
        // imagePath: photo.path || '',
        // imageName: photo.fileName || '',
      }
      const imageName = data.serverImagePath.replace('/storage/image/', '')
      const PATH_TO_WRITE = `${RNFetchBlob.fs.dirs.DocumentDir}/Pictures/${imageName}`

      record.imagePath = PATH_TO_WRITE
      console.log('PATH_TO_WRITE', PATH_TO_WRITE, record)
      Image.getSize(`${SITE_URL}${data.serverImagePath}`, (width, height) => {
        console.log('serverImagePath', `${SITE_URL}${data.serverImagePath}`, width, height);
        record.pixelWidth = width
        record.pixelHeight = height
        try {
          realm.write(() => {
            const art = realm.create('arts', record, true);
            console.log('realm.write', art)
            // fsStore.scanFile(record.imagePath)
          });
        } catch (error) {
          console.log('realm create art error', error)
        }

      });

      const index = stateStore.artList.find((item) => {
        return item.qrCode === record.qrCode
      })

      if (index) {
        index.isAdded = true
        console.log('qrCode added', index, record.qrCode)
      }

      if (cb && typeof cb === 'function') {
        cb(true)
      }


      if (data.serverImagePath) {
        console.log('url ', `${SITE_URL}${data.serverImagePath}`)

        stateStore.isLoading = true
        RNFetchBlob
          .config({
            // useDownloadManager : true,
            fileCache: true
          })
          .fetch('GET', `${SITE_URL}${data.serverImagePath}`, {})
          .then((res) => {
            console.log('RNFetchBlob res', res);
            stateStore.isLoading = false

            console.log('The file saved to ', res.path());

            RNFetchBlob.fs.mv(res.path(), PATH_TO_WRITE)
              .then((res) => {
                console.log('move file res', res);
              })
              .catch((error) => {
                console.log('move file error', error)
              })
          })
          .catch((err) => {
            stateStore.isLoading = false
            console.log('RNFetchBlob err', err)
          })
      }
    })
  }

  @action addArtByQrCode = async (qrCode, cb) => {
    console.log('art by qrCode', qrCode, stateStore.isConnected)

    const isAdded = realm.objects('arts').filtered(`qrCode = "${qrCode}"`);

    console.log('isAdded', isAdded.length)
    if (!!isAdded.length) {
      Alert.alert('Art Already In Library', 'The artwork for the QR code is already in your library.')
    }

    if (stateStore.isConnected && qrCode) {
      try {
        stateStore.isLoading = true
        const response = await axios.get(`/art?qr=${qrCode}`);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (response.data) {
            this.addArt(response.data)
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          uiStore.showError('Error get Artist List')
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

  /**
   * Gallery Directory
   * @param cb
   * @returns {Promise.<void>}
   */
  @action galleryList = async (cb) => {
    console.log('gallery list', stateStore.isConnected)
    stateStore.galleryDirectory = []
    if (stateStore.isConnected) {
      try {
        stateStore.isLoading = true
        const response = await axios.get(`/galleryList`);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (response.data) {
            stateStore.galleryDirectory = map(response.data, (item, index) => {return {index, item}});
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          uiStore.showError('Error get Gallery Directory')
        }
      }
    } else {
      uiStore.noConnect()
    }
  }

  /**
   * Artist List
   * @param cb
   * @returns {Promise.<void>}
   */
  @action artistList = async (galleryID, cb) => {
    console.log('artist list', galleryID, stateStore.isConnected)
    stateStore.artistList = []
    if (stateStore.isConnected && galleryID) {
      try {
        stateStore.isLoading = true
        const response = await axios.get(`/artistList?galleryID=${galleryID}`);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (response.data) {
            stateStore.artistList = map(response.data, (item, index) => {return {index, item}});
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          uiStore.showError('Error get Artist List')
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

  /**
   * Art List
   * @param cb
   * @returns {Promise.<void>}
   */
  @action artList = async (galleryID, firstName, lastName, cb) => {
    console.log('art list', galleryID, firstName, lastName, stateStore.isConnected)
    stateStore.artList  = []
    if (stateStore.isConnected && galleryID) {
      try {
        stateStore.isLoading = true
        const response = await axios.get(`/artList?galleryID=${galleryID}&firstName=${firstName}&lastName=${lastName}`);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false
          if (response.data) {
            stateStore.artList = map(response.data, (item) => {return item});
            this.checkArtList()
          }

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          uiStore.showError('Error get Artist List')
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

  checkArtList = () => {
    stateStore.artList = map(stateStore.artList, (item) => {
      const isAdded = realm.objects('arts').filtered(`qrCode = "${item.qrCode}"`);
      console.log('isAdded', isAdded.length, item.qrCode)
      return {
        ...item,
        isAdded: !!isAdded.length
      }
    })
  }

  /**
   * Load default arts from DB
   * @param cb
   * @returns {Promise.<void>}
   */
  @action load = async (cb) => {
    console.log('load default arts', stateStore.isConnected)
    if (stateStore.isConnected) {
      try {
        stateStore.isLoading = true
        const response = await axios.get(`/defaultArt`);
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false
          if (response.data) {
            // stateStore.arts = response.data;

            forEach(response.data, (data) => {
              this.addArt(data)
            })

            AsyncStorage.setItem('artLoaded', 'true')
              .then(res => {
                console.log('artLoaded set', true);
                stateStore.artLoaded = true;
              })
              .catch(error => {console.log('artLoaded error', error); stateStore.artLoaded = false });

            if (cb && typeof cb === 'function') {
              cb(true)
            }
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          stateStore.responseErrors = error.response
          uiStore.showError('Error get arts')
        }
      }
    } else {
      uiStore.noConnect()
    }
  }

  @action delete = (id) => {
    try {
      realm.write(() => {
        const item = realm.objectForPrimaryKey('arts', id);

        if (item) {
          const hangups = realm.objects('hangups').slice()
          const exist = find(hangups, (item) => {return find(item.arts.slice(), (i) => i.artId === id)})

          if (exist) {
            Alert.alert('Art Exists in Hangup', 'The artwork can`t be deleted from your library because it has been added to a hangup. To remove it from your library first remove it from any hangups.',
              [
                {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
              ],
              { cancelable: true }
            )
          } else {
            realm.delete(item);
          }

        }
      });
    } catch (error) {
      console.log('realm delete art error', error)
    }
  }

  @action toggleFavorit = (id) => {
    try {
      realm.write(() => {
        const item = realm.objectForPrimaryKey('arts', id);

        if (item) {
          item.isFavorite = !item.isFavorite
        }
      });
    } catch (error) {
      console.log('realm create art', error)
    }
  }

  /**
   * Reserve Art
   * @param email
   */
  @action reserve = async (data, cb) => {
    const { email, facebookID } = stateStore.user
    console.log('Reserve Art', {...data, email, facebookID, password: stateStore.password})

    if (stateStore.isConnected && stateStore.user) {
      try {
        stateStore.isLoading = true
        const response = await axios.post(`/reserve`, {...data, email, facebookID, password: stateStore.password});
        runInAction("update state after fetching data", () => {
          console.log('response', response.data)
          stateStore.isLoading = false

          if (cb && typeof cb === 'function') {
            cb(true)
          }
        })
      } catch (error) {
        stateStore.isLoading = false
        if (error.response) {
          console.log('error', error, error.response)
          stateStore.responseErrors = error.response
          Alert.alert("Connection Error",
            'There was a connection error while trying to connect. Please verify you have internet access and try again.',
            [
              {text: 'Cancel', onPress: () => console.log('CANCEL: Reserve Error Response')}
            ],
            {cancelable: true}
          )
        }
      }
    } else {
      if (!stateStore.isConnected) {
        uiStore.noConnect()
      }
    }
  }

}

export default new ArtStore();