import { observable, runInAction, action, autorun, computed, reaction, ObservableMap } from 'mobx';
import _ from 'lodash'
import RNFetchBlob from 'react-native-fetch-blob'
import stateStore from '@store/state'
import { Platform, Alert } from 'react-native'

const mime = require('mime');

class fsStore {
  rootDir = ''; // Корневая директория приложения
  dirs = {};
  localPaths = [
    {type: 'trash', path: '/.trash'},
    {type: 'images', path: '/arts', mime: 'image'},
  ]

  constructor () {
    // new Promise((resolve, reject) => {resolve(this.initDirs())})
    //   .then(() => {
    //   console.log('rootDir', this.rootDir)
      // Alert.alert('rootDir', this.rootDir)

      // Alert.alert('dirs', `${JSON.stringify(this.dirs)}`,
      //   [
      //     {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
      //     {text: 'OK', onPress: () => console.log('OK Pressed')},
      //   ],
      //   { cancelable: false }
      // )

      // RNFetchBlob.fs.unlink(`${this.dirs.images}/image-fcff3e72-568a-473b-835d-aef5fba362de.jpg`)
      //   .then(() => {
      //     this.scanFile(`${this.dirs.images}/image-fcff3e72-568a-473b-835d-aef5fba362de.jpg`)
      //     RNFetchBlob.fs.ls(this.dirs.images)
      //     // files will an array contains filenames
      //       .then((files) => {
      //         console.log(files)
      //         Alert.alert('files', `${files}`)
      //       })
      //   })
      //   .catch((err) => { Alert.alert('error delete', `${err}`)})

      // RNFetchBlob.fs.ls(this.rootDir)
      //   .then((files) => {
      //     console.log(files)
      //     // Alert.alert('files', `${files}`)
      //   })

      // RNFetchBlob.fs.ls('/storage/emulated/0/artsee/')
      //   .then((files) => {
      //     console.log(files)
      //     // Alert.alert('images', `${files}`)
      //     // this.scanFile('/storage/emulated/0/daLadno/Media/daLadno Profile Photos/test88')
      //   })

      // console.log('image/jpg', this.getType('image/jpg'))
      // console.log('application/png', this.getType('application/png'))
      // console.log('video/mp4', this.getType('video/mp4'))
      // console.log('audio/mp3', this.getType('audio/mp3'))
    // })
  }

  initDirs = async () => {
    const bundleDir = RNFetchBlob.fs.dirs.MainBundleDir

    if (Platform.OS === 'ios') {
      this.rootDir = bundleDir
    } else {

      if (RNFetchBlob.fs.dirs.SDCardDir) {
        const extRoot = RNFetchBlob.fs.dirs.SDCardDir + '/artsee'
        console.log('extRoot', extRoot)
        const isDir2 = await RNFetchBlob.fs.isDir(extRoot)

        this.rootDir = extRoot

        if (!isDir2) {
          await RNFetchBlob.fs.mkdir(extRoot)
            // .then(() => {
            //   this.rootDir = extRoot
            // })
            // .catch((err) => {
            //   this.rootDir = bundleDir
            // })
        }
      } else {
        this.rootDir = RNFetchBlob.fs.dirs.MainBundleDir
      }
    }

    _.forEach(this.localPaths, (item) => {
      let path = this.rootDir + item.path

      // let isDir = await RNFetchBlob.fs.isDir(path)

      // if (!isDir) {
        this.dirs[item.type] = path

        RNFetchBlob.fs.mkdir(path)
          .then(() => {
            console.log('${path} created')
          })
          .catch((err) => { console.log('error create ${path}', err) })
    })
  }

  @action scanFile = (target) => {
    // console.log('scan', RNFetchBlob.fs.dirs.MainBundleDir, target)
    if (Platform.OS === 'android') {
      // RNFetchBlob.fs.scanFile([ { path : target, mime : type } ])
      RNFetchBlob.fs.scanFile([ { path : target } ])
        .then(() => {
          // scan file success
          console.log('scanFile done')
          // Alert.alert('scanFile done')
        })
        .catch((err) => {
          // scan file error
          console.log('scanFile err', err)
          // Alert.alert('scanFile err', `${err}`)
        })
    }
  }

  @action moveFile = ({fileName, path, type}) => {
    return new Promise((resolve, reject) => {
      RNFetchBlob.fs.exists(path)
        .then((exist) => {
          console.log(`file ${exist ? '' : 'not'} exists`)

          if (exist) {
            const target = this.getDirByMime(type) + '/' + fileName

            RNFetchBlob.fs.mv(path, target)
              .then(() => {
                console.log('img moved')
                // Alert.alert(`img moved`, `${path} to ${target}`)
                this.scanFile(path)
                this.scanFile(target)
                resolve(target)
              })
              .catch((err) => {
                console.log('img move error', err)
                reject(err)
              })
          } else {
            reject()
          }

        })
        .catch((err) => {
          console.log('isExist', path, err)
          reject(err)
        })
    })
  }

  deleteFile = (path) => {
    RNFetchBlob.fs.isDir(path)
      .then((isDir) => {
        // console.log(`file is ${isDir ? '' : 'not'} a directory`)
        if (!isDir) {
          RNFetchBlob.fs.unlink(path)
            .then(() => {
              this.scanFile(path)
              console.log('deleted file', path)
            })
            .catch((err) => { console.log('delete file error', path, err)})
        }
      })

  }

  saveProfileImage = (username, path) => {
    console.log('saveProfileImage', username)
    return new Promise((resolve, reject) => {
      if (stateStore.isConnected) {
        const method = 'GET';
        const path = path || `${ this.dirs.trash }/${ Random }.temp`
        const uri = `${ stateStore.Site_Url }/avatar/${ username }`;

        let task = RNFetchBlob.config({path}).fetch(method, uri);
        // let task = RNFetchBlob.fetch(method, uri);
        task.then((res) => {
          const contentType = res && res.info() && res.info().headers && res.info().headers['content-type']
          const ext = mime.getExtension(contentType)
          console.log('extension avatar', username, ext)

          // let type = _.split(mime, '/');
          // type = _.size(type) > 0 ? type[0] : null;

          if (_.indexOf(['jpg', 'jpeg', 'png'], ext) !== -1) {
            const source = res.path()
            const target = `${ this.dirs.avatars }/${ username }.${ ext }`
            RNFetchBlob.fs.mv(source, target)
              .then(() => {
                console.log('img moved')
                // Alert.alert(`img moved`, `${path} to ${target}`)
                console.log('target avatar', source, target)
                this.scanFile(source)
                this.scanFile(target)
                resolve(target)
              })
              .catch((err) => {
                console.log('img move error', err)
                reject(err)
              })

            // this.scanFile(res.data) // TODO удалить сканирование для аватаров
            // resolve(path)
          } else {
            RNFetchBlob.fs.unlink(path);
            reject()
          }

          console.log('fetch username avatar', ext, mime, uri, res.info(), res)
        }).catch((err) => {
          console.log('fetch username avatar error', uri, err)
          // Parts of the image may have been downloaded already, (see https://github.com/wkh237/react-native-fetch-blob/issues/331)
          RNFetchBlob.fs.unlink(path);
          reject(err)
        });
      } else {
        reject()
      }
    })
  }

  getProfileImage = (username) => {
    const path = this.dirs.avatars + '/' + username + '.jpg'

    return new Promise((resolve, reject) => {
      RNFetchBlob.fs.exists(path)
        .then((exist) => {
          console.log(`avatar ${ username } ${exist ? '' : 'not'} exists`)

          if (!exist) {
            this.saveProfileImage(username, path)
              .then((resPath) => {
                resolve(resPath, true)
              })
              .catch(() => {reject()})
          } else {
            resolve(path)
          }
        })
        .catch(() => {
          console.log(`file exist error`)
          reject()
        })
    })
  }

  @action clearStore = () => {
    _.forEach(this.dirs, (dir) => {
      RNFetchBlob.fs.ls(dir)
      // files will an array contains filenames
        .then((files) => {
          _.forEach(files, (file) => {
            this.deleteFile(dir + '/' + file)
          })
        })
    })
  }
}

export default new fsStore();