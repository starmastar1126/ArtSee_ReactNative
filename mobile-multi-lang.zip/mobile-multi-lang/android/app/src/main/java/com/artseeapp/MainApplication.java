package com.artseeapp;

import android.app.Application;

//import de.interwebs.pesdk.PESDKPackage;
import com.facebook.react.ReactApplication;
import com.devialab.exif.RCTExifPackage;
import fr.greweb.rnwebgl.RNWebGLPackage;
import fr.bamlab.rnimageresizer.ImageResizerPackage;
import cl.json.RNSharePackage;
import fr.greweb.reactnativeviewshot.RNViewShotPackage;
import com.reactnative.ivpusic.imagepicker.PickerPackage;
import im.shimo.react.prompt.RNPromptPackage;
import com.chirag.RNMail.RNMail;
import io.github.traviskn.rnuuidgenerator.RNUUIDGeneratorPackage;
import org.reactnative.camera.RNCameraPackage;
import io.realm.react.RealmReactPackage;
import com.RNFetchBlob.RNFetchBlobPackage;
import com.imagepicker.ImagePickerPackage;
import com.oblador.vectoricons.VectorIconsPackage;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.soloader.SoLoader;
import com.magus.fblogin.FacebookLoginPackage;
import cl.json.ShareApplication;

import java.util.Arrays;
import java.util.List;

//import ly.img.android.PESDK;

public class MainApplication extends Application implements ShareApplication, ReactApplication {

  private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
    @Override
    public boolean getUseDeveloperSupport() {
      return BuildConfig.DEBUG;
    }

    @Override
    protected List<ReactPackage> getPackages() {
      return Arrays.<ReactPackage>asList(
          new MainReactPackage(),
            new RNWebGLPackage(),
            new ImageResizerPackage(),
            new RNSharePackage(),
            new RNViewShotPackage(),
            new PickerPackage(),
            new RNPromptPackage(),
            new RNMail(),
            new RNUUIDGeneratorPackage(),
            new RNCameraPackage(),
            new RealmReactPackage(),
            new RNFetchBlobPackage(),
            new ImagePickerPackage(),
            new VectorIconsPackage(),
            new RCTExifPackage(),
            //new PESDKPackage(),
            new FacebookLoginPackage()
      );
    }

    @Override
    protected String getJSMainModuleName() {
      return "index";
    }
  };

  @Override
  public ReactNativeHost getReactNativeHost() {
    return mReactNativeHost;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    SoLoader.init(this, /* native exopackage */ false);
    //PESDK.init(this, "android_license");
  }

  @Override
       public String getFileProviderAuthority() {
              return "com.artseeapp.provider";
       }
}
